package com.example.tvlauncher

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.location.Location
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.URLEncoder
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.tan

private class Place(val name: String, val admin: String, val country: String, val lat: Double, val lon: Double)

class SettingsActivity : Activity() {

    private val bg = 0xFF0B1220.toInt()
    private val card = 0xFF141C2E.toInt()
    private val itemColor = 0xFF1C2740.toInt()
    private val accent = 0xFF2F6BFF.toInt()
    private val selGreen = 0xFF1E8E5A.toInt()
    private val muted = 0xFFB4BFD1.toInt()
    private val gold = 0xFFFFC857.toInt()

    private lateinit var prefs: SharedPreferences
    private lateinit var tvLocInfo: TextView
    private lateinit var tvStatus: TextView
    private lateinit var mapView: ImageView
    private lateinit var cityEdit: EditText
    private lateinit var resultsBox: LinearLayout
    private lateinit var bgStatus: TextView
    private lateinit var grid: GridLayout
    private lateinit var btnOn: TextView
    private lateinit var tvDim: TextView
    private val modeBtns = LinkedHashMap<String, TextView>()
    private val intervalBtns = LinkedHashMap<Int, TextView>()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, r: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(r).toFloat()
    }

    private fun tv(s: String, sp: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = sp; setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun setSel(v: TextView, sel: Boolean) {
        v.tag = sel
        v.background = rounded(if (v.isFocused) accent else if (sel) selGreen else itemColor, 12)
    }

    private fun btn(label: String, sp: Float = 16f, onClick: () -> Unit): TextView =
        tv(label, sp, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            isFocusable = true
            isClickable = true
            setPadding(dp(14), dp(8), dp(14), dp(8))
            background = rounded(itemColor, 12)
            setOnFocusChangeListener { v, f ->
                v.background = rounded(if (f) accent else if (v.tag == true) selGreen else itemColor, 12)
            }
            setOnClickListener { onClick() }
        }

    private fun row(vararg views: View): LinearLayout = LinearLayout(this).apply {
        for (v in views) {
            addView(v, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f).apply {
                setMargins(dp(4), dp(4), dp(4), dp(4))
            })
        }
    }

    private fun column(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(18), dp(14), dp(18), dp(14))
    }

    private fun LinearLayout.add(v: View, top: Int = 8) {
        addView(v, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(top) })
    }

    private fun scroll(v: View): ScrollView = ScrollView(this).apply {
        isFillViewport = true
        background = rounded(card, 18)
        addView(v)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("launcher", MODE_PRIVATE)
        val root = LinearLayout(this).apply {
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(bg)
            setPadding(dp(32), dp(20), dp(32), dp(20))
        }
        val lp1 = LinearLayout.LayoutParams(0, MATCH_PARENT, 1f).apply { setMargins(dp(8), 0, dp(8), 0) }
        val lp2 = LinearLayout.LayoutParams(0, MATCH_PARENT, 1f).apply { setMargins(dp(8), 0, dp(8), 0) }
        root.addView(scroll(buildLocation()), lp1)
        root.addView(scroll(buildBackground()), lp2)
        setContentView(root)
        refreshLocInfo()
        refreshBgUi()
        showSavedMap()
    }

    // ================= الموقع والخريطة =================
    private fun buildLocation(): View {
        val col = column()
        col.add(tv("الموقع والخريطة", 22f, Color.WHITE, true), 0)
        tvLocInfo = tv("", 15f, muted)
        col.add(tvLocInfo)

        val auto = btn("تلقائي") { setAuto() }
        val gps = btn("GPS") { useGps() }
        val manual = btn("يدوي") {
            tvStatus.text = "اكتب اسم مدينتك ثم اضغط بحث"
            cityEdit.requestFocus()
        }
        modeBtns["auto"] = auto
        modeBtns["gps"] = gps
        modeBtns["manual"] = manual
        col.add(row(auto, gps, manual))

        cityEdit = EditText(this).apply {
            hint = "اكتب اسم المدينة (مثال: باتنة)"
            setHintTextColor(muted)
            setTextColor(Color.WHITE)
            textSize = 18f
            setSingleLine(true)
            imeOptions = EditorInfo.IME_ACTION_SEARCH
            background = rounded(itemColor, 12)
            setPadding(dp(14), dp(10), dp(14), dp(10))
            setOnEditorActionListener { _, id, _ ->
                if (id == EditorInfo.IME_ACTION_SEARCH) {
                    search()
                    true
                } else {
                    false
                }
            }
        }
        col.add(cityEdit)
        col.add(btn("بحث") { search() })
        tvStatus = tv("", 15f, gold)
        col.add(tvStatus)
        resultsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.add(resultsBox)

        mapView = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            background = rounded(itemColor, 12)
        }
        col.addView(mapView, LinearLayout.LayoutParams(MATCH_PARENT, dp(250)).apply { topMargin = dp(10) })
        col.add(tv("© OpenStreetMap contributors", 11f, muted), 4)
        return col
    }

    private fun refreshLocInfo() {
        val mode = prefs.getString("loc_mode", "auto") ?: "auto"
        val city = prefs.getString("city", "") ?: ""
        val lat = prefs.getString("lat", null)?.toDoubleOrNull()
        val lon = prefs.getString("lon", null)?.toDoubleOrNull()
        var info = "الموقع الحالي: " + (if (city.isBlank()) "غير محدد" else city)
        if (lat != null && lon != null) info += "\n" + String.format(Locale.US, "%.3f , %.3f", lat, lon)
        tvLocInfo.text = info
        for ((k, v) in modeBtns) setSel(v, k == mode)
    }

    private fun status(msg: String) {
        tvStatus.text = msg
    }

    private fun saveLocation(mode: String, lat: Double, lon: Double, city: String) {
        prefs.edit()
            .putString("loc_mode", mode)
            .putString("lat", lat.toString())
            .putString("lon", lon.toString())
            .putString("city", city)
            .apply()
        status("تم حفظ الموقع: $city")
        resultsBox.removeAllViews()
        refreshLocInfo()
        loadMap(lat, lon)
    }

    private fun setAuto() {
        status("جارٍ تحديد الموقع من الإنترنت…")
        thread {
            val l = ipLocation()
            runOnUiThread {
                if (l != null) {
                    saveLocation("auto", l.first, l.second, l.third)
                } else {
                    prefs.edit().putString("loc_mode", "auto").apply()
                    status("تعذّر التحديد، تحقق من الإنترنت")
                    refreshLocInfo()
                }
            }
        }
    }

    private fun useGps() {
        if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            status("سيطلب التلفزيون إذن الموقع، اختر «السماح»")
            requestPermissions(
                arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION), 11
            )
            return
        }
        val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val providers = lm.getProviders(true).filter { it != LocationManager.PASSIVE_PROVIDER }
        if (providers.isEmpty()) {
            status("هذا التلفزيون لا يملك GPS أو خدمة الموقع مغلقة. استخدم «تلقائي» أو «يدوي».")
            return
        }
        status("جارٍ تحديد الموقع بالـ GPS…")
        try {
            lm.getCurrentLocation(providers[0], null, mainExecutor) { loc: Location? -> onGps(loc) }
        } catch (e: SecurityException) {
            status("لا يوجد إذن للموقع")
        }
    }

    private fun onGps(loc: Location?) {
        if (loc == null) {
            status("تعذّر الحصول على الموقع، جرّب «يدوي»")
            return
        }
        val lat = loc.latitude
        val lon = loc.longitude
        thread {
            val name = reverseName(lat, lon) ?: "موقع GPS"
            runOnUiThread { saveLocation("gps", lat, lon, name) }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 11) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                useGps()
            } else {
                status("لم يُمنح إذن الموقع")
            }
        }
    }

    private fun search() {
        val q = cityEdit.text.toString().trim()
        if (q.isEmpty()) {
            status("اكتب اسم المدينة أولاً")
            return
        }
        status("جارٍ البحث…")
        thread {
            val body = httpGet(
                "https://geocoding-api.open-meteo.com/v1/search?name=" + URLEncoder.encode(q, "UTF-8") +
                    "&count=8&language=ar&format=json"
            )
            val items = ArrayList<Place>()
            try {
                val arr = JSONObject(body ?: "{}").optJSONArray("results")
                if (arr != null) {
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        items.add(
                            Place(
                                o.optString("name"), o.optString("admin1"), o.optString("country"),
                                o.getDouble("latitude"), o.getDouble("longitude")
                            )
                        )
                    }
                }
            } catch (e: Exception) {
            }
            runOnUiThread { showResults(items, body != null) }
        }
    }

    private fun showResults(items: List<Place>, online: Boolean) {
        resultsBox.removeAllViews()
        if (items.isEmpty()) {
            status(if (online) "لا توجد نتائج، جرّب اسماً آخر" else "تعذّر الاتصال بالإنترنت")
            return
        }
        status("اختر مدينتك:")
        for (p in items) {
            val label = listOf(p.name, p.admin, p.country).filter { it.isNotEmpty() }.joinToString("، ")
            resultsBox.add(btn(label, 16f) { saveLocation("manual", p.lat, p.lon, p.name) }, 6)
        }
        resultsBox.getChildAt(0)?.requestFocus()
    }

    private fun showSavedMap() {
        val f = File(filesDir, "map.png")
        if (f.exists()) {
            val b = BitmapFactory.decodeFile(f.absolutePath)
            if (b != null) mapView.setImageBitmap(b)
        }
        val lat = prefs.getString("lat", null)?.toDoubleOrNull()
        val lon = prefs.getString("lon", null)?.toDoubleOrNull()
        if (lat != null && lon != null) {
            if (prefs.getString("map_key", "") != mapKey(lat, lon) || !f.exists()) loadMap(lat, lon)
        }
    }

    private fun mapKey(lat: Double, lon: Double) = String.format(Locale.US, "%.2f,%.2f", lat, lon)

    // خريطة من OpenStreetMap: 9 بلاطات حول الموقع + دبوس أحمر
    private fun loadMap(lat: Double, lon: Double) {
        val z = 10
        val n = 1 shl z
        val xf = (lon + 180.0) / 360.0 * n
        val latRad = Math.toRadians(lat)
        val yf = (1.0 - ln(tan(latRad) + 1.0 / cos(latRad)) / PI) / 2.0 * n
        val xt = floor(xf).toInt()
        val yt = floor(yf).toInt()
        thread {
            val bmp = Bitmap.createBitmap(768, 768, Bitmap.Config.ARGB_8888)
            val cv = Canvas(bmp)
            cv.drawColor(0xFF1C2740.toInt())
            var ok = false
            for (dy in -1..1) {
                for (dx in -1..1) {
                    val tx = ((xt + dx) % n + n) % n
                    val ty = yt + dy
                    if (ty < 0 || ty >= n) continue
                    val bytes = httpBytes("https://tile.openstreetmap.org/$z/$tx/$ty.png") ?: continue
                    val t = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: continue
                    cv.drawBitmap(t, ((dx + 1) * 256).toFloat(), ((dy + 1) * 256).toFloat(), null)
                    ok = true
                }
            }
            if (!ok) {
                runOnUiThread { status("تعذّر تحميل الخريطة (تحقق من الإنترنت)") }
                return@thread
            }
            val px = (256 + (xf - xt) * 256).toFloat()
            val py = (256 + (yf - yt) * 256).toFloat()
            val white = Paint(Paint.ANTI_ALIAS_FLAG)
            white.color = Color.WHITE
            val red = Paint(Paint.ANTI_ALIAS_FLAG)
            red.color = 0xFFD21034.toInt()
            cv.drawCircle(px, py, 22f, white)
            cv.drawCircle(px, py, 15f, red)
            try {
                FileOutputStream(File(filesDir, "map.png")).use { bmp.compress(Bitmap.CompressFormat.PNG, 90, it) }
                prefs.edit().putString("map_key", mapKey(lat, lon)).apply()
            } catch (e: Exception) {
            }
            runOnUiThread { mapView.setImageBitmap(bmp) }
        }
    }

    // ================= الخلفية والتطبيقات =================
    private fun buildBackground(): View {
        val col = column()
        col.add(tv("الخلفية المتحركة", 22f, Color.WHITE, true), 0)
        btnOn = btn("") {
            prefs.edit().putBoolean("bg_on", !prefs.getBoolean("bg_on", true)).apply()
            refreshBgUi()
        }
        col.add(btnOn)
        col.add(tv("مدة ظهور كل صورة (بالثواني):", 15f, muted))
        val views = ArrayList<View>()
        for (s in listOf(10, 15, 30, 60)) {
            val b = btn("$s") {
                prefs.edit().putInt("bg_interval", s).apply()
                refreshBgUi()
            }
            intervalBtns[s] = b
            views.add(b)
        }
        col.add(row(*views.toTypedArray()))
        tvDim = tv("", 15f, muted)
        col.add(tvDim)
        col.add(row(btn("−  أخف") { changeDim(-10) }, btn("+  أغمق") { changeDim(10) }))
        col.add(btn("إضافة صور من الملفات") { pickImages() }, 12)
        bgStatus = tv("", 15f, gold)
        col.add(bgStatus)
        col.add(
            tv(
                "نصيحة: أرسل صورك للتلفزيون عبر Send Files to TV ثم اخترها من مجلد Download. الصور الأفقية تظهر أفضل.",
                13f, muted
            )
        )

        col.add(tv("التطبيقات", 20f, Color.WHITE, true), 16)
        col.add(tv("لنقل أي تطبيق أو إخفائه: اضغط مطولاً على OK فوق التطبيق في الشاشة الرئيسية.", 13f, muted))
        col.add(
            row(
                btn("إظهار المخفية") {
                    prefs.edit().remove("app_hidden").apply()
                    bgStatus.text = "تم إظهار كل التطبيقات"
                },
                btn("الترتيب الافتراضي") {
                    prefs.edit().remove("app_order").apply()
                    bgStatus.text = "تمت إعادة الترتيب الافتراضي"
                }
            )
        )

        col.add(tv("صورك (اضغط OK على صورة لحذفها):", 15f, Color.WHITE, true), 16)
        grid = GridLayout(this).apply { columnCount = 3 }
        col.add(grid)
        return col
    }

    private fun changeDim(delta: Int) {
        val v = (prefs.getInt("bg_dim", 55) + delta).coerceIn(0, 90)
        prefs.edit().putInt("bg_dim", v).apply()
        refreshBgUi()
    }

    private fun refreshBgUi() {
        val on = prefs.getBoolean("bg_on", true)
        btnOn.text = if (on) "الخلفية المتحركة: مفعّلة (اضغط للتعطيل)" else "الخلفية المتحركة: معطّلة (اضغط للتفعيل)"
        val itv = prefs.getInt("bg_interval", 15)
        for ((s, b) in intervalBtns) setSel(b, s == itv)
        tvDim.text = "درجة التعتيم: " + prefs.getInt("bg_dim", 55) + "%"
        val files = bgFiles(this)
        thread {
            val items = files.map { f ->
                val o = BitmapFactory.Options()
                o.inSampleSize = 8
                o.inPreferredConfig = Bitmap.Config.RGB_565
                val b: Bitmap? = try {
                    BitmapFactory.decodeFile(f.absolutePath, o)
                } catch (e: Throwable) {
                    null
                }
                Pair(f, b)
            }
            runOnUiThread {
                grid.removeAllViews()
                for ((f, bmp) in items) {
                    val lp = GridLayout.LayoutParams()
                    lp.width = dp(130)
                    lp.height = dp(84)
                    lp.setMargins(dp(4), dp(4), dp(4), dp(4))
                    grid.addView(thumb(f, bmp), lp)
                }
                if (items.isEmpty()) bgStatus.text = "لا توجد صور بعد، تظهر خلفية ألوان متحركة افتراضية"
            }
        }
    }

    private fun thumb(f: File, bmp: Bitmap?): View {
        val wrap = FrameLayout(this).apply {
            isFocusable = true
            isClickable = true
            setPadding(dp(3), dp(3), dp(3), dp(3))
            background = rounded(itemColor, 8)
            setOnFocusChangeListener { v, focus -> v.background = rounded(if (focus) accent else itemColor, 8) }
            setOnClickListener {
                AlertDialog.Builder(this@SettingsActivity)
                    .setTitle("حذف هذه الصورة؟")
                    .setPositiveButton("حذف") { _, _ ->
                        f.delete()
                        refreshBgUi()
                    }
                    .setNegativeButton("إلغاء", null)
                    .show()
            }
        }
        val iv = ImageView(this)
        iv.scaleType = ImageView.ScaleType.CENTER_CROP
        if (bmp != null) iv.setImageBitmap(bmp)
        wrap.addView(iv, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        return wrap
    }

    private fun pickImages() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "image/*"
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        try {
            startActivityForResult(i, 21)
        } catch (e: Exception) {
            try {
                val g = Intent(Intent.ACTION_GET_CONTENT)
                g.type = "image/*"
                g.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                startActivityForResult(g, 21)
            } catch (e2: Exception) {
                bgStatus.text = "لا يوجد تطبيق ملفات لاختيار الصور (جرّب تثبيت مدير ملفات)"
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 21 || resultCode != RESULT_OK || data == null) return
        val uris = ArrayList<Uri>()
        val clip = data.clipData
        if (clip != null) {
            for (i in 0 until clip.itemCount) uris.add(clip.getItemAt(i).uri)
        } else {
            val u = data.data
            if (u != null) uris.add(u)
        }
        bgStatus.text = "جارٍ إضافة الصور…"
        thread {
            var count = 0
            for (u in uris) if (importImage(u)) count++
            runOnUiThread {
                bgStatus.text = "تمت إضافة $count صورة"
                refreshBgUi()
            }
        }
    }

    // نسخ الصورة إلى مخزن التطبيق بحجم مناسب (حتى 1920x1080)
    private fun importImage(uri: Uri): Boolean {
        return try {
            val bounds = BitmapFactory.Options()
            bounds.inJustDecodeBounds = true
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / sample > 2400 || bounds.outHeight / sample > 1400) sample *= 2
            val o = BitmapFactory.Options()
            o.inSampleSize = sample
            val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
                ?: return false
            val scale = minOf(1920f / bmp.width, 1080f / bmp.height, 1f)
            val out = if (scale < 1f) {
                Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt(), (bmp.height * scale).toInt(), true)
            } else {
                bmp
            }
            val name = "bg_" + System.currentTimeMillis() + "_" + (Math.random() * 1000).toInt() + ".jpg"
            FileOutputStream(File(bgDir(this), name)).use { out.compress(Bitmap.CompressFormat.JPEG, 88, it) }
            true
        } catch (e: Throwable) {
            false
        }
    }
}
