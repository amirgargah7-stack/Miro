package com.example.tvlauncher

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

private const val UA = "MiroLauncherTV/1.0 (Android TV launcher)"

fun httpBytes(u: String): ByteArray? = try {
    val c = URL(u).openConnection() as HttpURLConnection
    c.connectTimeout = 8000
    c.readTimeout = 10000
    c.setRequestProperty("User-Agent", UA)
    val b = c.inputStream.use { it.readBytes() }
    c.disconnect()
    b
} catch (e: Exception) {
    null
}

fun httpGet(u: String): String? = httpBytes(u)?.toString(Charsets.UTF_8)

// الموقع التقريبي من عنوان الإنترنت (lat, lon, city)
fun ipLocation(): Triple<Double, Double, String>? {
    for (u in listOf("https://ipwho.is/", "https://ipapi.co/json/")) {
        try {
            val body = httpGet(u) ?: continue
            val j = JSONObject(body)
            if (j.has("latitude") && j.has("longitude") && j.optBoolean("success", true)) {
                return Triple(j.getDouble("latitude"), j.getDouble("longitude"), j.optString("city", ""))
            }
        } catch (e: Exception) {
        }
    }
    return null
}

// اسم المدينة من الإحداثيات (للـ GPS)
fun reverseName(lat: Double, lon: Double): String? {
    val b = httpGet(
        "https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=$lat&longitude=$lon&localityLanguage=ar"
    ) ?: return null
    return try {
        val j = JSONObject(b)
        listOf("city", "locality", "principalSubdivision").map { j.optString(it) }.firstOrNull { it.isNotEmpty() }
    } catch (e: Exception) {
        null
    }
}
