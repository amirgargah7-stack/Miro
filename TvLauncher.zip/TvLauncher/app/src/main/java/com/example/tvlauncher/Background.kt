package com.example.tvlauncher

import android.animation.ArgbEvaluator
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import java.io.File
import kotlin.concurrent.thread
import kotlin.random.Random

fun bgDir(ctx: Context): File = File(ctx.filesDir, "bg").apply { mkdirs() }

fun bgFiles(ctx: Context): List<File> =
    (bgDir(ctx).listFiles() ?: emptyArray<File>()).filter { it.extension == "jpg" }.sortedBy { it.name }

// خلفية متحركة: عرض صور مع انتقال تدريجي وتقريب بطيء، أو تدرّج ألوان متحرك إن لم توجد صور
class BackgroundView(private val ctx: Context) : FrameLayout(ctx) {
    private val mp = ViewGroup.LayoutParams.MATCH_PARENT
    private val gradientView = View(ctx)
    private val a = ImageView(ctx)
    private val b = ImageView(ctx)
    private val dim = View(ctx)
    private val handler = Handler(Looper.getMainLooper())
    private val grad = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        intArrayOf(0xFF0B1220.toInt(), 0xFF06301F.toInt(), 0xFF0B1220.toInt())
    )
    private val c1 = intArrayOf(0xFF0B1220.toInt(), 0xFF06301F.toInt(), 0xFF0B1220.toInt())
    private val c2 = intArrayOf(0xFF06301F.toInt(), 0xFF0B1220.toInt(), 0xFF2A0A12.toInt())
    private val ev = ArgbEvaluator()
    private var colorAnim: ValueAnimator? = null
    private var files: List<File> = emptyList()
    private var index = 0
    private var showingA = true
    private var intervalMs = 15000L
    private var token = 0

    init {
        gradientView.background = grad
        a.scaleType = ImageView.ScaleType.CENTER_CROP
        b.scaleType = ImageView.ScaleType.CENTER_CROP
        a.alpha = 0f
        b.alpha = 0f
        addView(gradientView, FrameLayout.LayoutParams(mp, mp))
        addView(a, FrameLayout.LayoutParams(mp, mp))
        addView(b, FrameLayout.LayoutParams(mp, mp))
        addView(dim, FrameLayout.LayoutParams(mp, mp))
    }

    fun reload(prefs: SharedPreferences) {
        stop()
        val on = prefs.getBoolean("bg_on", true)
        intervalMs = prefs.getInt("bg_interval", 15) * 1000L
        val dimPct = prefs.getInt("bg_dim", 35).coerceIn(0, 90)
        files = bgFiles(ctx)
        a.alpha = 0f
        b.alpha = 0f
        a.setImageDrawable(null)
        b.setImageDrawable(null)
        if (!on || files.isEmpty()) {
            gradientView.visibility = View.VISIBLE
            dim.setBackgroundColor(Color.TRANSPARENT)
            startGradient()
        } else {
            gradientView.visibility = View.GONE
            dim.setBackgroundColor(Color.argb(dimPct * 255 / 100, 0, 0, 0))
            index = 0
            showNext()
        }
    }

    fun stop() {
        token++
        handler.removeCallbacksAndMessages(null)
        a.animate().cancel()
        b.animate().cancel()
        colorAnim?.cancel()
        colorAnim = null
    }

    override fun onDetachedFromWindow() {
        stop()
        super.onDetachedFromWindow()
    }

    private fun startGradient() {
        colorAnim?.cancel()
        val anim = ValueAnimator.ofFloat(0f, 1f)
        anim.duration = 12000
        anim.repeatCount = ValueAnimator.INFINITE
        anim.repeatMode = ValueAnimator.REVERSE
        anim.addUpdateListener {
            val t = it.animatedFraction
            grad.colors = intArrayOf(
                ev.evaluate(t, c1[0], c2[0]) as Int,
                ev.evaluate(t, c1[1], c2[1]) as Int,
                ev.evaluate(t, c1[2], c2[2]) as Int
            )
        }
        anim.start()
        colorAnim = anim
    }

    private fun showNext() {
        val myToken = token
        if (files.isEmpty()) return
        val f = files[index % files.size]
        index++
        thread {
            val opts = BitmapFactory.Options()
            opts.inPreferredConfig = Bitmap.Config.RGB_565
            val bmp: Bitmap? = try {
                BitmapFactory.decodeFile(f.absolutePath, opts)
            } catch (e: Throwable) {
                null
            }
            handler.post {
                if (myToken == token) {
                    if (bmp != null) crossfadeTo(bmp)
                    handler.postDelayed({
                        if (myToken == token) showNext()
                    }, intervalMs)
                }
            }
        }
    }

    private fun crossfadeTo(bmp: Bitmap) {
        val incoming = if (showingA) b else a
        val outgoing = if (showingA) a else b
        showingA = !showingA
        incoming.animate().cancel()
        incoming.setImageBitmap(bmp)
        incoming.alpha = 0f
        incoming.scaleX = 1f
        incoming.scaleY = 1f
        incoming.translationX = 0f
        incoming.translationY = 0f
        incoming.bringToFront()
        dim.bringToFront()
        ObjectAnimator.ofFloat(incoming, View.ALPHA, 0f, 1f).setDuration(1500).start()
        val dx = Random.nextInt(-40, 41).toFloat()
        val dy = Random.nextInt(-25, 26).toFloat()
        incoming.animate()
            .scaleX(1.12f).scaleY(1.12f)
            .translationX(dx).translationY(dy)
            .setDuration(intervalMs + 3000)
            .setInterpolator(LinearInterpolator())
            .start()
        handler.postDelayed({
            outgoing.alpha = 0f
            outgoing.setImageDrawable(null)
        }, 1700)
    }
}
