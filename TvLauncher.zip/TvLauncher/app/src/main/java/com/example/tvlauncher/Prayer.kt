package com.example.tvlauncher

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.LinearLayout
import java.util.Calendar
import java.util.Locale

object PT {
    fun offset(p: SharedPreferences, key: String): Int = p.getInt("off_$key", 0)

    fun setOffset(p: SharedPreferences, key: String, v: Int) {
        p.edit().putInt("off_$key", v.coerceIn(-30, 30)).apply()
    }

    fun cal(p: SharedPreferences, key: String, tomorrow: Boolean = false): Calendar? {
        val raw = p.getString("p_$key", null) ?: return null
        val parts = raw.split(":")
        if (parts.size < 2) return null
        val h = parts[0].trim().toIntOrNull() ?: return null
        val m = parts[1].trim().toIntOrNull() ?: return null
        val c = Calendar.getInstance()
        c.set(Calendar.HOUR_OF_DAY, h)
        c.set(Calendar.MINUTE, m)
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        c.add(Calendar.MINUTE, offset(p, key))
        if (tomorrow) c.add(Calendar.DAY_OF_YEAR, 1)
        return c
    }

    fun fmt(p: SharedPreferences, c: Calendar): String {
        val h = c.get(Calendar.HOUR_OF_DAY)
        val m = c.get(Calendar.MINUTE)
        return if (p.getBoolean("clock_24", true)) {
            String.format(Locale.US, "%02d:%02d", h, m)
        } else {
            val h12 = if (h % 12 == 0) 12 else h % 12
            String.format(Locale.US, "%d:%02d %s", h12, m, if (h < 12) "ص" else "م")
        }
    }

    // الأذان القادم (يتجاوز الشروق). بعد العشاء يعرض فجر الغد.
    fun next(p: SharedPreferences): Pair<Int, Calendar>? {
        val now = Calendar.getInstance()
        for (i in K.prayers.indices) {
            val key = K.prayers[i].first
            if (key == "Sunrise") continue
            val c = cal(p, key) ?: continue
            if (c.after(now)) return Pair(i, c)
        }
        val c = cal(p, "Fajr", true) ?: return null
        return Pair(0, c)
    }
}

// صفوف ضبط الأذان: لكل صلاة وقتها وأزرارها (− / + / إعادة)
fun buildPrayerRows(ctx: Context, prefs: SharedPreferences, onChange: () -> Unit): LinearLayout {
    val col = LinearLayout(ctx)
    col.orientation = LinearLayout.VERTICAL
    col.layoutDirection = View.LAYOUT_DIRECTION_RTL
    for (p in K.prayers) {
        val key = p.first
        val row = LinearLayout(ctx)
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(ctx.dp(14), ctx.dp(6), ctx.dp(10), ctx.dp(6))
        row.background = ctx.rounded(0x66141C2E, 14)
        val nameTv = ctx.tv(p.second, 18f, Color.WHITE, true)
        val timeTv = ctx.tv("", 22f, Color.WHITE, true)
        val offTv = ctx.tv("", 14f, K.GOLD, true)
        fun refresh() {
            val c = PT.cal(prefs, key)
            timeTv.text = if (c != null) PT.fmt(prefs, c) else "--:--"
            val off = PT.offset(prefs, key)
            offTv.text = if (off != 0) (if (off > 0) "+" else "") + off + " د" else ""
        }
        val minus = ctx.btn("−", 22f, 18) {
            PT.setOffset(prefs, key, PT.offset(prefs, key) - 1)
            refresh()
            onChange()
        }
        val plus = ctx.btn("+", 22f, 18) {
            PT.setOffset(prefs, key, PT.offset(prefs, key) + 1)
            refresh()
            onChange()
        }
        val reset = ctx.btn("إعادة", 14f, 12) {
            PT.setOffset(prefs, key, 0)
            refresh()
            onChange()
        }
        row.addView(nameTv, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        row.addView(timeTv, LinearLayout.LayoutParams(ctx.dp(120), WRAP_CONTENT))
        row.addView(offTv, LinearLayout.LayoutParams(ctx.dp(70), WRAP_CONTENT))
        for (b in listOf(minus, plus, reset)) {
            row.addView(b, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply {
                setMargins(ctx.dp(4), 0, ctx.dp(4), 0)
            })
        }
        refresh()
        col.addView(row, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = ctx.dp(6) })
    }
    return col
}
