package com.example.tvlauncher

import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread

class AppItem(val label: String, val icon: Drawable, val pkg: String, val cls: String)

class MainActivity : Activity() {

    private val prayers = listOf(
        "Fajr" to "الفجر", "Sunrise" to "الشروق", "Dhuhr" to "الظهر",
        "Asr" to "العصر", "Maghrib" to "المغرب", "Isha" to "العشاء"
    )
    private val card = 0xCC141C2E.toInt()
    private val itemColor = 0xCC1C2740.toInt()
    private val accent = 0xFF2F6BFF.toInt()
    private val muted = 0xFFB4BFD1.toInt()
    private val gold = 0xFFFFC857.toInt()

    private val adapter = AppAdapter()
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var prefs: SharedPreferences
    private lateinit var bgView: BackgroundView
    private lateinit var tvDate: TextView
    private lateinit var tvTemp: TextView
    private lateinit var tvWeather: TextView
    private lateinit var tvNext: TextView
    private lateinit var appList: RecyclerView
    private val cells = ArrayList<LinearLayout>()
    private val cellTimes = ArrayList<TextView>()
    private var allApps: List<AppItem> = emptyList()
    private var ticks = 0
    private var lastHighlight = -1
    private var offsetMin = 0
    private var focusedOnce = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, r: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(r).toFloat()
    }

    private fun tv(s: String, sp: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = sp; setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun button(label: String, sp: Float, hPad: Int, onClick: () -> Unit): TextView =
        tv(label, sp, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            isFocusable = true
            isClickable = true
            setPadding(dp(hPad), dp(4), dp(hPad), dp(4))
            background = rounded(itemColor, 12)
            setOnFocusChangeListener { v, f -> v.background = rounded(if (f) accent else itemColor, 12) }
            setOnClickListener { onClick() }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("launcher", MODE_PRIVATE)
        offsetMin = prefs.getInt("offset", 0)
        seedDefaults()

        bgView = BackgroundView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(40), dp(20), dp(40), dp(20))
        }

        // ===== الرأس: الشعار والاسم + الوقت + الطقس =====
        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }

        val brandBox = LinearLayout(this).apply {
            gravity = Gravity.START or Gravity.CENTER_VERTICAL
        }
        brandBox.addView(
            ImageView(this).apply { setImageResource(R.drawable.ic_logo) },
            LinearLayout.LayoutParams(dp(76), dp(76))
        )
        brandBox.addView(tv("Miro Launcher TV", 24f, Color.WHITE, true).apply {
            setPadding(dp(12), 0, dp(12), 0)
        })
        header.addView(brandBox, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))

        val clockBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        clockBox.addView(TextClock(this).apply {
            format12Hour = "HH:mm"; format24Hour = "HH:mm"
            textSize = 44f; setTextColor(Color.WHITE)
            setTypeface(typeface, Typeface.BOLD)
        })
        tvDate = tv("", 16f, muted)
        clockBox.addView(tvDate)
        header.addView(clockBox, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))

        val weatherBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.END
        }
        tvTemp = tv("--°", 36f, Color.WHITE, true)
        tvWeather = tv("", 15f, muted)
        weatherBox.addView(tvTemp)
        weatherBox.addView(tvWeather)
        header.addView(weatherBox, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))

        // ===== بطاقة مواقيت الصلاة =====
        val prayerCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(card, 18)
            setPadding(dp(16), dp(12), dp(16), dp(12))
        }
        tvNext = tv("جارٍ تحميل مواقيت الصلاة…", 20f, gold, true).apply { gravity = Gravity.CENTER }
        val topRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        topRow.addView(button("+", 22f, 20) { changeOffset(1) })
        topRow.addView(tvNext, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        topRow.addView(button("−", 22f, 20) { changeOffset(-1) })
        prayerCard.addView(topRow, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))

        val row = LinearLayout(this).apply { setPadding(0, dp(10), 0, 0) }
        for (p in prayers) {
            val cell = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(0, dp(8), 0, dp(8))
                background = rounded(Color.TRANSPARENT, 12)
            }
            cell.addView(tv(p.second, 16f, muted).apply { gravity = Gravity.CENTER })
            val t = tv("--:--", 22f, Color.WHITE, true).apply { gravity = Gravity.CENTER }
            cell.addView(t)
            cells.add(cell)
            cellTimes.add(t)
            row.addView(cell, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f).apply {
                setMargins(dp(4), 0, dp(4), 0)
            })
        }
        prayerCard.addView(row, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))

        // ===== بطاقة التطبيقات (خانة وحدها) =====
        val appsCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(card, 18)
            setPadding(dp(16), dp(12), dp(16), dp(8))
        }
        val appsHeader = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        appsHeader.addView(
            tv("التطبيقات  •  اضغط مطولاً على OK لنقل التطبيق أو إخفائه", 16f, muted, true),
            LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f)
        )
        appsHeader.addView(button("الإعدادات", 15f, 16) {
            startActivity(Intent(this, SettingsActivity::class.java))
        })
        appsCard.addView(appsHeader, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))

        appList = RecyclerView(this).apply {
            layoutManager = GridLayoutManager(this@MainActivity, 6)
            adapter = this@MainActivity.adapter
            clipToPadding = false
            setPadding(0, dp(8), 0, dp(8))
            setHasFixedSize(true)
            itemAnimator = null
        }
        appsCard.addView(appList, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))

        content.addView(header, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        content.addView(prayerCard, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(12) })
        content.addView(appsCard, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f).apply { topMargin = dp(12) })

        val frame = FrameLayout(this)
        frame.addView(bgView, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        frame.addView(content, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        setContentView(frame)
        renderStatic()
    }

    // أول تشغيل: نسخ صور الخلفية الجاهزة إلى مخزن التطبيق (يمكن حذفها من الإعدادات)
    private fun seedDefaults() {
        if (prefs.getBoolean("bg_seeded", false)) return
        try {
            val names = assets.list("defaults") ?: emptyArray()
            for (n in names) {
                assets.open("defaults/$n").use { input ->
                    java.io.FileOutputStream(java.io.File(bgDir(this), "bg_0_$n")).use { out ->
                        input.copyTo(out)
                    }
                }
            }
        } catch (e: Exception) {
        }
        prefs.edit().putBoolean("bg_seeded", true).apply()
    }

    override fun onResume() {
        super.onResume()
        bgView.reload(prefs)
        loadApps()
        refreshData()
        handler.removeCallbacks(ticker)
        handler.post(ticker)
    }

    override fun onPause() {
        super.onPause()
        bgView.stop()
        handler.removeCallbacks(ticker)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {}

    private val ticker = object : Runnable {
        override fun run() {
            updateCountdown()
            ticks++
            if (ticks % 1800 == 0) refreshData()
            else if (ticks % 60 == 0) {
                if (prefs.getString("p_date", "") != todayStr()) refreshData()
                tvDate.text = dateText()
            }
            handler.postDelayed(this, 1000)
        }
    }

    private fun changeOffset(delta: Int) {
        offsetMin = (offsetMin + delta).coerceIn(-15, 15)
        prefs.edit().putInt("offset", offsetMin).apply()
        lastHighlight = -1
        renderStatic()
    }

    // ===== الشبكة: الموقع + الصلاة + الطقس =====
    private fun refreshData() {
        thread {
            if ((prefs.getString("loc_mode", "auto") ?: "auto") == "auto") {
                ipLocation()?.let {
                    prefs.edit()
                        .putString("lat", it.first.toString())
                        .putString("lon", it.second.toString())
                        .putString("city", it.third)
                        .apply()
                }
            }
            val lat = prefs.getString("lat", null)
            val lon = prefs.getString("lon", null)
            if (lat != null && lon != null) {
                fetchPrayers(lat, lon)
                fetchWeather(lat, lon)
            }
            runOnUiThread { renderStatic() }
        }
    }

    private fun todayStr(): String = SimpleDateFormat("dd-MM-yyyy", Locale.US).format(Date())

    private fun fetchPrayers(lat: String, lon: String) {
        val today = todayStr()
        val loc = "$lat,$lon"
        if (prefs.getString("p_date", "") == today && prefs.getString("p_loc", "") == loc &&
            prefs.contains("p_Fajr")
        ) return
        val body = httpGet("https://api.aladhan.com/v1/timings/$today?latitude=$lat&longitude=$lon") ?: return
        try {
            val t = JSONObject(body).getJSONObject("data").getJSONObject("timings")
            val e = prefs.edit()
            for (p in prayers) e.putString("p_" + p.first, t.getString(p.first).take(5))
            e.putString("p_date", today).putString("p_loc", loc).apply()
        } catch (ex: Exception) {
        }
    }

    private fun fetchWeather(lat: String, lon: String) {
        val body = httpGet(
            "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,weather_code"
        ) ?: return
        try {
            val c = JSONObject(body).getJSONObject("current")
            prefs.edit()
                .putString("temp", c.getDouble("temperature_2m").toString())
                .putInt("wcode", c.getInt("weather_code"))
                .apply()
        } catch (ex: Exception) {
        }
    }

    // ===== العرض =====
    private fun dateText(): String =
        SimpleDateFormat("EEEE، d MMMM yyyy", Locale.forLanguageTag("ar-u-nu-latn")).format(Date())

    private fun weatherText(code: Int): String = when (code) {
        0 -> "صافٍ"
        1, 2 -> "غائم جزئياً"
        3 -> "غائم"
        45, 48 -> "ضباب"
        in 51..67, in 80..82 -> "مطر"
        in 71..77, 85, 86 -> "ثلج"
        in 95..99 -> "عاصفة رعدية"
        else -> ""
    }

    private fun renderStatic() {
        tvDate.text = dateText()
        val temp = prefs.getString("temp", null)?.toDoubleOrNull()
        tvTemp.text = if (temp != null) "\u200E" + Math.round(temp) + "°" else "--°"
        val city = prefs.getString("city", "") ?: ""
        val desc = if (temp != null) weatherText(prefs.getInt("wcode", 0)) else ""
        tvWeather.text = listOf(desc, city).filter { it.isNotEmpty() }.joinToString(" • ")
        for (i in prayers.indices) {
            val raw = prefs.getString("p_" + prayers[i].first, null)
            cellTimes[i].text = if (raw != null) shown(raw) else "--:--"
        }
        updateCountdown()
    }

    private fun timeToday(s: String): Calendar? {
        val parts = s.split(":")
        if (parts.size < 2) return null
        val h = parts[0].trim().toIntOrNull() ?: return null
        val m = parts[1].trim().toIntOrNull() ?: return null
        return Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, h)
            set(Calendar.MINUTE, m)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            add(Calendar.MINUTE, offsetMin)
        }
    }

    private fun shown(t: String): String {
        val c = timeToday(t) ?: return t
        return String.format(Locale.US, "%02d:%02d", c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE))
    }

    // الأذان القادم (يتجاوز الشروق). بعد العشاء يعرض فجر الغد.
    private fun nextPrayer(): Pair<Int, Calendar>? {
        val now = Calendar.getInstance()
        for (i in prayers.indices) {
            if (prayers[i].first == "Sunrise") continue
            val t = prefs.getString("p_" + prayers[i].first, null) ?: continue
            val c = timeToday(t) ?: continue
            if (c.after(now)) return Pair(i, c)
        }
        val f = prefs.getString("p_Fajr", null) ?: return null
        val c = timeToday(f) ?: return null
        c.add(Calendar.DAY_OF_YEAR, 1)
        return Pair(0, c)
    }

    private fun updateCountdown() {
        val np = nextPrayer()
        if (np == null) {
            tvNext.text = "جارٍ تحميل مواقيت الصلاة… (تأكد من اتصال الإنترنت)"
            return
        }
        val diff = ((np.second.timeInMillis - System.currentTimeMillis()) / 1000).coerceAtLeast(0)
        val h = diff / 3600
        val m = (diff % 3600) / 60
        val s = diff % 60
        tvNext.text = "الأذان القادم: " + prayers[np.first].second + "  •  بعد " +
            String.format(Locale.US, "%02d:%02d:%02d", h, m, s) +
            (if (offsetMin != 0) "   (ضبط " + (if (offsetMin > 0) "+" else "") + offsetMin + " د)" else "")
        if (lastHighlight != np.first) {
            lastHighlight = np.first
            for (i in cells.indices) {
                cells[i].background = rounded(if (i == np.first) accent else Color.TRANSPARENT, 12)
            }
        }
    }

    // ===== التطبيقات: تحميل + ترتيب + إخفاء =====
    private fun loadApps() {
        thread {
            val pm = packageManager
            var intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
            val tvApps = pm.queryIntentActivities(intent, 0)
            intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val all = (tvApps + pm.queryIntentActivities(intent, 0))
                .distinctBy { it.activityInfo.packageName }
                .filter { it.activityInfo.packageName != packageName }
            val items = all.map {
                val ai = it.activityInfo
                AppItem(it.loadLabel(pm).toString(), it.loadIcon(pm), ai.packageName, ai.name)
            }.sortedBy { it.label.lowercase() }
            runOnUiThread {
                allApps = items
                adapter.submit(orderedVisible(), false)
                if (!focusedOnce && items.isNotEmpty()) {
                    focusedOnce = true
                    appList.postDelayed({ appList.getChildAt(0)?.requestFocus() }, 400)
                }
            }
        }
    }

    private fun hiddenSet(): Set<String> = prefs.getStringSet("app_hidden", emptySet()) ?: emptySet()

    private fun orderedVisible(): List<AppItem> {
        val hidden = hiddenSet()
        val order = (prefs.getString("app_order", "") ?: "").split("\n").filter { it.isNotEmpty() }
        return allApps.filter { it.pkg !in hidden }.sortedWith(
            compareBy<AppItem>({
                val i = order.indexOf(it.pkg)
                if (i < 0) Int.MAX_VALUE else i
            }, { it.label.lowercase() })
        )
    }

    private fun focusPosition(pos: Int) {
        appList.scrollToPosition(pos)
        appList.postDelayed({
            (appList.layoutManager as? GridLayoutManager)?.findViewByPosition(pos)?.requestFocus()
        }, 250)
    }

    // mode: 0 خطوة للأمام، 1 خطوة للخلف، 2 إلى البداية
    private fun moveApp(pkg: String, mode: Int) {
        val cur = orderedVisible().map { it.pkg }.toMutableList()
        val i = cur.indexOf(pkg)
        if (i < 0) return
        cur.removeAt(i)
        val ni = when (mode) {
            0 -> maxOf(0, i - 1)
            1 -> minOf(cur.size, i + 1)
            else -> 0
        }
        cur.add(ni, pkg)
        prefs.edit().putString("app_order", cur.joinToString("\n")).apply()
        adapter.submit(orderedVisible(), true)
        focusPosition(ni)
    }

    private fun hideApp(pkg: String) {
        val before = orderedVisible().map { it.pkg }
        val idx = before.indexOf(pkg).coerceAtLeast(0)
        val s = HashSet<String>(hiddenSet())
        s.add(pkg)
        prefs.edit().putStringSet("app_hidden", s).apply()
        val after = orderedVisible()
        adapter.submit(after, true)
        if (after.isNotEmpty()) focusPosition(minOf(idx, after.size - 1))
    }

    private fun showAppMenu(item: AppItem) {
        val options = arrayOf("تحريك خطوة للأمام", "تحريك خطوة للخلف", "نقل إلى البداية", "إخفاء التطبيق")
        AlertDialog.Builder(this)
            .setTitle(item.label)
            .setItems(options) { _, which ->
                if (which == 3) hideApp(item.pkg) else moveApp(item.pkg, which)
            }
            .show()
    }

    private inner class AppAdapter : RecyclerView.Adapter<AppAdapter.VH>() {
        private var items: List<AppItem> = emptyList()

        fun submit(newItems: List<AppItem>, force: Boolean) {
            if (!force && newItems.map { it.pkg } == items.map { it.pkg }) return
            items = newItems
            notifyDataSetChanged()
        }

        inner class VH(val box: LinearLayout, val icon: ImageView, val name: TextView) :
            RecyclerView.ViewHolder(box)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val box = LinearLayout(parent.context).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                isFocusable = true
                setPadding(dp(6), dp(10), dp(6), dp(8))
                layoutParams = RecyclerView.LayoutParams(MATCH_PARENT, dp(108)).apply {
                    setMargins(dp(6), dp(6), dp(6), dp(6))
                }
                background = rounded(itemColor, 14)
                setOnFocusChangeListener { v, focused ->
                    v.background = rounded(if (focused) accent else itemColor, 14)
                    v.animate().scaleX(if (focused) 1.08f else 1f)
                        .scaleY(if (focused) 1.08f else 1f).setDuration(120).start()
                    v.elevation = if (focused) dp(8).toFloat() else 0f
                }
            }
            val icon = ImageView(parent.context)
            box.addView(icon, LinearLayout.LayoutParams(dp(52), dp(52)))
            val name = TextView(parent.context).apply {
                textSize = 13f
                setTextColor(Color.WHITE)
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                gravity = Gravity.CENTER
                setPadding(0, dp(8), 0, 0)
            }
            box.addView(name, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
            return VH(box, icon, name)
        }

        override fun onBindViewHolder(h: VH, position: Int) {
            val item = items[position]
            h.icon.setImageDrawable(item.icon)
            h.name.text = item.label
            h.box.setOnClickListener {
                val i = Intent(Intent.ACTION_MAIN)
                    .setComponent(ComponentName(item.pkg, item.cls))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(i)
            }
            h.box.setOnLongClickListener {
                showAppMenu(item)
                true
            }
        }

        override fun getItemCount() = items.size
    }
}
