package com.example.tvlauncher

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlin.concurrent.thread

class AppItem(val label: String, val icon: Drawable, val pkg: String, val cls: String)

class MainActivity : Activity() {

    private val adapter = AppAdapter()
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF0F1115.toInt())
            setPadding(dp(48), dp(28), dp(48), dp(16))
        }

        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        header.addView(TextView(this).apply {
            text = "التطبيقات"; textSize = 28f; setTextColor(Color.WHITE)
        }, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        header.addView(TextClock(this).apply {
            format12Hour = "hh:mm a"; format24Hour = "HH:mm"
            textSize = 26f; setTextColor(0xFFB8C0CC.toInt())
        })
        root.addView(header, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))

        val list = RecyclerView(this).apply {
            layoutManager = GridLayoutManager(this@MainActivity, 6)
            adapter = this@MainActivity.adapter
            clipToPadding = false
            setPadding(0, dp(24), 0, dp(24))
            setHasFixedSize(true)
            itemAnimator = null
        }
        root.addView(list, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        loadApps()
    }

    // زر الرجوع لا يغلق الواجهة
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {}

    private fun loadApps() {
        thread {
            val pm = packageManager
            var intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
            var found = pm.queryIntentActivities(intent, 0)
            // تطبيقات الموبايل العادية التي ليس لها نسخة للتلفزيون
            intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val all = (found + pm.queryIntentActivities(intent, 0))
                .distinctBy { it.activityInfo.packageName }
                .filter { it.activityInfo.packageName != packageName }
            val items = all.map {
                val ai = it.activityInfo
                AppItem(it.loadLabel(pm).toString(), it.loadIcon(pm), ai.packageName, ai.name)
            }.sortedBy { it.label.lowercase() }
            runOnUiThread { adapter.submit(items) }
        }
    }

    private inner class AppAdapter : RecyclerView.Adapter<AppAdapter.VH>() {
        private var items: List<AppItem> = emptyList()

        fun submit(newItems: List<AppItem>) {
            if (newItems.map { it.pkg } == items.map { it.pkg }) return
            items = newItems
            notifyDataSetChanged()
        }

        inner class VH(val box: LinearLayout, val icon: ImageView, val name: TextView) :
            RecyclerView.ViewHolder(box)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val box = LinearLayout(parent.context).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                isFocusable = true
                setPadding(dp(8), dp(16), dp(8), dp(12))
                layoutParams = RecyclerView.LayoutParams(MATCH_PARENT, dp(140)).apply {
                    setMargins(dp(8), dp(8), dp(8), dp(8))
                }
                background = bg(0xFF1A1E26.toInt())
                setOnFocusChangeListener { v, focused ->
                    v.background = bg(if (focused) 0xFF2F6BFF.toInt() else 0xFF1A1E26.toInt())
                    v.animate().scaleX(if (focused) 1.1f else 1f)
                        .scaleY(if (focused) 1.1f else 1f).setDuration(120).start()
                    v.elevation = if (focused) dp(8).toFloat() else 0f
                }
            }
            val icon = ImageView(parent.context)
            box.addView(icon, LinearLayout.LayoutParams(dp(64), dp(64)))
            val name = TextView(parent.context).apply {
                textSize = 14f; setTextColor(Color.WHITE); maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
                gravity = Gravity.CENTER
                setPadding(0, dp(10), 0, 0)
            }
            box.addView(name, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
            return VH(box, icon, name)
        }

        override fun onBindViewHolder(h: VH, position: Int) {
            val item = items[position]
            h.icon.setImageDrawable(item.icon)
            h.name.text = item.label
            h.box.setOnClickListener {
                val i = Intent(Intent.ACTION_MAIN)
                    .setComponent(ComponentName(item.pkg, item.cls))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(i)
            }
        }

        override fun getItemCount() = items.size

        private fun bg(color: Int) = GradientDrawable().apply {
            setColor(color); cornerRadius = dp(14).toFloat()
        }
    }
}
