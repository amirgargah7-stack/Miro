package com.example.tvlauncher

import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread

private class Row(val header: String?, val app: AppItem?)

class MainActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var store: AppStore
    private lateinit var bgView: BackgroundView
    private lateinit var clockView: TextClock
    private lateinit var tvDate: TextView
    private lateinit var tvTemp: TextView
    private lateinit var tvWeather: TextView
    private lateinit var tvNextTitle: TextView
    private lateinit var tvNextCd: TextView
    private lateinit var nextPill: LinearLayout
    private lateinit var brandBox: LinearLayout
    private lateinit var weatherBox: LinearLayout
    private lateinit var appList: RecyclerView
    private lateinit var gridLm: GridLayoutManager
    private val adapter = AppAdapter()
    private val handler = Handler(Looper.getMainLooper())
    private var allApps: List<AppItem> = emptyList()
    private var rows: List<Row> = emptyList()
    private var ticks = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = K.prefs(this)
        store = AppStore(this)
        seedDefaults()
        bgView = BackgroundView(this)
        val acc = K.accent(prefs)

        val content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.layoutDirection = View.LAYOUT_DIRECTION_RTL

        // ===== الشريط العلوي: الشعار | الأذان القادم | الوقت والطقس والإعدادات =====
        val topBar = LinearLayout(this)
        topBar.gravity = Gravity.CENTER_VERTICAL
        topBar.setPadding(dp(48), dp(20), dp(48), dp(18))
        topBar.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xAA000000.toInt(), 0x00000000)
        )

        brandBox = LinearLayout(this)
        brandBox.gravity = Gravity.START or Gravity.CENTER_VERTICAL
        val logo = ImageView(this)
        logo.setImageResource(R.drawable.ic_logo)
        brandBox.addView(logo, LinearLayout.LayoutParams(dp(56), dp(56)))
        val brandName = tv("Miro Launcher TV", 20f, Color.WHITE, true)
        brandName.setPadding(dp(12), 0, dp(12), 0)
        brandBox.addView(brandName)
        topBar.addView(brandBox, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))

        nextPill = LinearLayout(this)
        nextPill.orientation = LinearLayout.VERTICAL
        nextPill.gravity = Gravity.CENTER
        nextPill.isFocusable = true
        nextPill.isClickable = true
        nextPill.setPadding(dp(24), dp(8), dp(24), dp(8))
        nextPill.background = rounded(0x77141C2E, 26)
        nextPill.setOnFocusChangeListener { v, f -> v.background = rounded(if (f) acc else 0x77141C2E, 26) }
        nextPill.setOnClickListener { showPrayerSheet() }
        tvNextTitle = tv("جارٍ تحميل مواقيت الصلاة…", 16f, Color.WHITE, true)
        tvNextTitle.gravity = Gravity.CENTER
        tvNextCd = tv("", 15f, K.GOLD, true)
        tvNextCd.gravity = Gravity.CENTER
        nextPill.addView(tvNextTitle)
        nextPill.addView(tvNextCd)
        topBar.addView(nextPill, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT))

        val leftBox = LinearLayout(this)
        leftBox.gravity = Gravity.END or Gravity.CENTER_VERTICAL
        val timeBox = LinearLayout(this)
        timeBox.orientation = LinearLayout.VERTICAL
        timeBox.gravity = Gravity.CENTER_HORIZONTAL
        clockView = TextClock(this)
        clockView.textSize = 36f
        clockView.setTextColor(Color.WHITE)
        clockView.setTypeface(clockView.typeface, Typeface.BOLD)
        tvDate = tv("", 13f, K.MUTED)
        timeBox.addView(clockView)
        timeBox.addView(tvDate)
        leftBox.addView(timeBox)

        weatherBox = LinearLayout(this)
        weatherBox.orientation = LinearLayout.VERTICAL
        weatherBox.gravity = Gravity.CENTER_HORIZONTAL
        tvTemp = tv("--°", 26f, Color.WHITE, true)
        tvWeather = tv("", 13f, K.MUTED)
        weatherBox.addView(tvTemp)
        weatherBox.addView(tvWeather)
        leftBox.addView(weatherBox, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply {
            marginStart = dp(26)
        })

        val settingsBtn = btn("الإعدادات", 16f, 18) {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        leftBox.addView(settingsBtn, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply {
            marginStart = dp(26)
        })
        topBar.addView(leftBox, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))

        // ===== منطقة التطبيقات (أسفل الشاشة بأسلوب Apple TV) =====
        val appsArea = LinearLayout(this)
        appsArea.orientation = LinearLayout.VERTICAL
        appsArea.clipChildren = false
        appsArea.setPadding(dp(48), dp(18), dp(48), dp(6))
        appsArea.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0x00000000, 0xCC000000.toInt())
        )
        gridLm = GridLayoutManager(this, 7)
        gridLm.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int =
                if (position < rows.size && rows[position].header != null) gridLm.spanCount else 1
        }
        appList = RecyclerView(this)
        appList.layoutManager = gridLm
        appList.adapter = adapter
        appList.clipToPadding = false
        appList.clipChildren = false
        appList.setPadding(0, dp(6), 0, dp(14))
        appList.itemAnimator = null
        appsArea.addView(appList, LinearLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))

        content.addView(topBar, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        content.addView(View(this), LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        content.addView(appsArea, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1.25f))

        val frame = FrameLayout(this)
        frame.addView(bgView, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        frame.addView(content, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        setContentView(frame)
        applyDisplaySettings()
        renderStatic()
    }

    // أول تشغيل: نسخ صور الخلفية الجاهزة إلى مخزن التطبيق
    private fun seedDefaults() {
        if (prefs.getBoolean("bg_seeded", false)) return
        try {
            val names = assets.list("defaults") ?: emptyArray()
            for (n in names) {
                assets.open("defaults/$n").use { input ->
                    java.io.FileOutputStream(java.io.File(bgDir(this), "bg_0_$n")).use { out ->
                        input.copyTo(out)
                    }
                }
            }
        } catch (e: Exception) {
        }
        prefs.edit().putBoolean("bg_seeded", true).apply()
    }

    override fun onResume() {
        super.onResume()
        bgView.reload(prefs)
        applyDisplaySettings()
        renderStatic()
        loadApps()
        refreshData()
        handler.removeCallbacks(ticker)
        handler.post(ticker)
    }

    override fun onPause() {
        super.onPause()
        bgView.stop()
        handler.removeCallbacks(ticker)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {}

    private val ticker = object : Runnable {
        override fun run() {
            updateCountdown()
            ticks++
            if (ticks % 1800 == 0) {
                refreshData()
            } else if (ticks % 60 == 0) {
                if (prefs.getString("p_date", "") != todayStr()) refreshData()
                tvDate.text = dateText()
            }
            handler.postDelayed(this, 1000)
        }
    }

    private fun applyDisplaySettings() {
        val f = if (prefs.getBoolean("clock_24", true)) "HH:mm" else "h:mm a"
        clockView.format12Hour = f
        clockView.format24Hour = f
        tvDate.visibility = if (prefs.getBoolean("show_date", true)) View.VISIBLE else View.GONE
        brandBox.visibility = if (prefs.getBoolean("show_brand", true)) View.VISIBLE else View.INVISIBLE
        nextPill.visibility = if (prefs.getBoolean("show_next", true)) View.VISIBLE else View.GONE
        weatherBox.visibility = if (prefs.getBoolean("show_weather", true)) View.VISIBLE else View.GONE
        val cols = K.colsOptions.getOrElse(prefs.getInt("cols_idx", 2)) { 7 }
        if (gridLm.spanCount != cols) gridLm.spanCount = cols
    }

    // ===== الشبكة: الموقع + الصلاة + الطقس =====
    private fun refreshData() {
        thread {
            if ((prefs.getString("loc_mode", "auto") ?: "auto") == "auto") {
                ipLocation()?.let {
                    prefs.edit()
                        .putString("lat", it.first.toString())
                        .putString("lon", it.second.toString())
                        .putString("city", it.third)
                        .apply()
                }
            }
            val lat = prefs.getString("lat", null)
            val lon = prefs.getString("lon", null)
            if (lat != null && lon != null) {
                fetchPrayers(lat, lon)
                fetchWeather(lat, lon)
            }
            runOnUiThread { renderStatic() }
        }
    }

    private fun todayStr(): String = SimpleDateFormat("dd-MM-yyyy", Locale.US).format(Date())

    private fun fetchPrayers(lat: String, lon: String) {
        val today = todayStr()
        val method = prefs.getInt("calc_method", -1)
        val school = if (prefs.getBoolean("asr_hanafi", false)) 1 else 0
        val loc = "$lat,$lon,$method,$school"
        if (prefs.getString("p_date", "") == today && prefs.getString("p_loc", "") == loc &&
            prefs.contains("p_Fajr")
        ) return
        var url = "https://api.aladhan.com/v1/timings/$today?latitude=$lat&longitude=$lon&school=$school"
        if (method >= 0) url += "&method=$method"
        val body = httpGet(url) ?: return
        try {
            val t = JSONObject(body).getJSONObject("data").getJSONObject("timings")
            val e = prefs.edit()
            for (p in K.prayers) e.putString("p_" + p.first, t.getString(p.first).take(5))
            e.putString("p_date", today).putString("p_loc", loc).apply()
        } catch (ex: Exception) {
        }
    }

    private fun fetchWeather(lat: String, lon: String) {
        val body = httpGet(
            "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,weather_code"
        ) ?: return
        try {
            val c = JSONObject(body).getJSONObject("current")
            prefs.edit()
                .putString("temp", c.getDouble("temperature_2m").toString())
                .putInt("wcode", c.getInt("weather_code"))
                .apply()
        } catch (ex: Exception) {
        }
    }

    // ===== العرض =====
    private fun dateText(): String =
        SimpleDateFormat("EEEE، d MMMM yyyy", Locale.forLanguageTag("ar-u-nu-latn")).format(Date())

    private fun weatherText(code: Int): String = when (code) {
        0 -> "صافٍ"
        1, 2 -> "غائم جزئياً"
        3 -> "غائم"
        45, 48 -> "ضباب"
        in 51..67, in 80..82 -> "مطر"
        in 71..77, 85, 86 -> "ثلج"
        in 95..99 -> "عاصفة رعدية"
        else -> ""
    }

    private fun renderStatic() {
        tvDate.text = dateText()
        val temp = prefs.getString("temp", null)?.toDoubleOrNull()
        if (temp != null) {
            val useF = prefs.getBoolean("temp_f", false)
            val v = if (useF) temp * 9.0 / 5.0 + 32.0 else temp
            tvTemp.text = "\u200E" + Math.round(v) + (if (useF) "°F" else "°C")
        } else {
            tvTemp.text = "--°"
        }
        val city = prefs.getString("city", "") ?: ""
        val desc = if (temp != null) weatherText(prefs.getInt("wcode", 0)) else ""
        tvWeather.text = listOf(desc, city).filter { it.isNotEmpty() }.joinToString(" • ")
        updateCountdown()
    }

    private fun updateCountdown() {
        val np = PT.next(prefs)
        if (np == null) {
            tvNextTitle.text = "جارٍ تحميل مواقيت الصلاة…"
            tvNextCd.text = ""
            return
        }
        val diff = ((np.second.timeInMillis - System.currentTimeMillis()) / 1000).coerceAtLeast(0)
        val h = diff / 3600
        val m = (diff % 3600) / 60
        val s = diff % 60
        tvNextTitle.text = "الأذان القادم: " + K.prayers[np.first].second + "  " + PT.fmt(prefs, np.second)
        tvNextCd.text = "بعد " + String.format(Locale.US, "%02d:%02d:%02d", h, m, s)
    }

    private fun showPrayerSheet() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.layoutDirection = View.LAYOUT_DIRECTION_RTL
        box.setPadding(dp(24), dp(18), dp(24), dp(10))
        box.setBackgroundColor(0xFF141C2E.toInt())
        box.addView(tv("أوقات الصلاة  •  اضبط كل أذان وحده", 18f, K.GOLD, true))
        box.addView(
            buildPrayerRows(this, prefs) { renderStatic() },
            LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(8) }
        )
        val dlg = AlertDialog.Builder(this).setView(box).setPositiveButton("تم", null).create()
        dlg.show()
        dlg.window?.setLayout(dp(760), ViewGroup.LayoutParams.WRAP_CONTENT)
    }

    // ===== التطبيقات =====
    private fun loadApps() {
        thread {
            val items = store.loadAll()
            runOnUiThread {
                allApps = items
                applyRows(true)
                if (!appList.hasFocus()) focusFirstApp()
            }
        }
    }

    private fun buildRows(): List<Row> {
        val s = store.sections(allApps)
        val out = ArrayList<Row>()
        if (s.pinned.isNotEmpty()) {
            out.add(Row("المفضلة", null))
            for (a in s.pinned) out.add(Row(null, a))
            out.add(Row("التطبيقات", null))
        }
        for (a in s.rest) out.add(Row(null, a))
        return out
    }

    private fun applyRows(rebuildViews: Boolean) {
        rows = buildRows()
        if (rebuildViews) appList.adapter = adapter else adapter.notifyDataSetChanged()
    }

    private fun focusPosition(pos: Int, delay: Long = 250) {
        if (pos < 0) return
        appList.scrollToPosition(pos)
        appList.postDelayed({ gridLm.findViewByPosition(pos)?.requestFocus() }, delay)
    }

    private fun focusFirstApp() {
        val p = rows.indexOfFirst { it.app != null }
        if (p >= 0) focusPosition(p, 400)
    }

    private fun posOf(pkg: String): Int = rows.indexOfFirst { it.app?.pkg == pkg }

    private fun showAppMenu(item: AppItem) {
        val pinned = store.isPinned(item.pkg)
        val options = arrayOf(
            if (pinned) "إلغاء التثبيت من المفضلة" else "تثبيت في المفضلة",
            "تحريك خطوة للأمام",
            "تحريك خطوة للخلف",
            "نقل إلى البداية",
            "إخفاء التطبيق",
            "إدارة كل التطبيقات…"
        )
        AlertDialog.Builder(this)
            .setTitle(item.label)
            .setItems(options) { _, which ->
                when (which) {
                    0 -> {
                        store.togglePin(item.pkg)
                        applyRows(false)
                        focusPosition(posOf(item.pkg))
                    }
                    1 -> moveApp(item, -1, false)
                    2 -> moveApp(item, 1, false)
                    3 -> moveApp(item, 0, true)
                    4 -> {
                        val before = posOf(item.pkg)
                        store.hide(item.pkg)
                        applyRows(false)
                        focusPosition(minOf(before, rows.size - 1))
                    }
                    else -> startActivity(Intent(this, SettingsActivity::class.java).putExtra("page", 5))
                }
            }
            .show()
    }

    private fun moveApp(item: AppItem, delta: Int, toStart: Boolean) {
        store.move(allApps, item.pkg, delta, toStart)
        applyRows(false)
        focusPosition(posOf(item.pkg))
    }

    private fun tileBg(f: Boolean): GradientDrawable {
        val g = rounded(if (f) 0x55FFFFFF else 0x2EFFFFFF, 26)
        if (f) g.setStroke(dp(3), Color.WHITE)
        return g
    }

    private inner class TileVH(
        val box: LinearLayout, val icon: ImageView, val label: TextView
    ) : RecyclerView.ViewHolder(box)

    private inner class AppAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

        override fun getItemCount() = rows.size

        override fun getItemViewType(position: Int): Int = if (rows[position].header != null) 0 else 1

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            if (viewType == 0) {
                val t = tv("", 20f, Color.WHITE, true)
                t.setPadding(dp(8), dp(10), dp(8), dp(2))
                t.layoutParams = RecyclerView.LayoutParams(MATCH_PARENT, WRAP_CONTENT)
                return object : RecyclerView.ViewHolder(t) {}
            }
            val sizes = intArrayOf(88, 104, 124)
            val p = sizes[prefs.getInt("icon_size", 1).coerceIn(0, 2)]
            val always = prefs.getBoolean("labels_always", false)
            val box = LinearLayout(parent.context)
            box.orientation = LinearLayout.VERTICAL
            box.gravity = Gravity.CENTER_HORIZONTAL
            box.isFocusable = true
            box.layoutParams = RecyclerView.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply {
                setMargins(dp(6), dp(8), dp(6), dp(8))
            }
            val plate = FrameLayout(parent.context)
            plate.background = tileBg(false)
            val icon = ImageView(parent.context)
            icon.scaleType = ImageView.ScaleType.FIT_CENTER
            val isz = (p * 0.68f).toInt()
            plate.addView(icon, FrameLayout.LayoutParams(dp(isz), dp(isz), Gravity.CENTER))
            box.addView(plate, LinearLayout.LayoutParams(dp(p), dp(p)))
            val label = TextView(parent.context)
            label.textSize = 14f
            label.setTextColor(Color.WHITE)
            label.maxLines = 1
            label.ellipsize = TextUtils.TruncateAt.END
            label.gravity = Gravity.CENTER
            label.setPadding(0, dp(8), 0, 0)
            label.alpha = if (always) 0.9f else 0f
            box.addView(label, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
            box.setOnFocusChangeListener { v, f ->
                plate.background = tileBg(f)
                plate.elevation = if (f) dp(18).toFloat() else 0f
                v.animate().scaleX(if (f) 1.14f else 1f).scaleY(if (f) 1.14f else 1f).setDuration(140).start()
                label.animate().alpha(if (f || always) 1f else 0f).setDuration(140).start()
            }
            return TileVH(box, icon, label)
        }

        override fun onBindViewHolder(h: RecyclerView.ViewHolder, position: Int) {
            val row = rows[position]
            val header = row.header
            if (header != null) {
                (h.itemView as TextView).text = header
                return
            }
            val item = row.app ?: return
            val t = h as TileVH
            t.icon.setImageDrawable(item.icon)
            t.label.text = item.label
            t.box.setOnClickListener {
                val i = Intent(Intent.ACTION_MAIN)
                    .setComponent(ComponentName(item.pkg, item.cls))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(i)
            }
            t.box.setOnLongClickListener {
                showAppMenu(item)
                true
            }
        }
    }
}
