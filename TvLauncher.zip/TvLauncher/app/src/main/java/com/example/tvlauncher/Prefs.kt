package com.example.tvlauncher

import android.content.Context
import android.content.SharedPreferences

object K {
    val prayers: List<Pair<String, String>> = listOf(
        "Fajr" to "الفجر", "Sunrise" to "الشروق", "Dhuhr" to "الظهر",
        "Asr" to "العصر", "Maghrib" to "المغرب", "Isha" to "العشاء"
    )
    val accents: List<Pair<String, Int>> = listOf(
        "الأزرق" to 0xFF2F6BFF.toInt(),
        "الأخضر" to 0xFF1E9E5A.toInt(),
        "الأحمر" to 0xFFD21034.toInt(),
        "الذهبي" to 0xFFE0A526.toInt()
    )
    val methods: List<Pair<String, Int>> = listOf(
        "تلقائي" to -1, "الجزائر" to 19, "رابطة العالم الإسلامي" to 3,
        "أم القرى" to 4, "مصر" to 5, "تونس" to 18, "المغرب" to 21
    )
    val colsOptions: List<Int> = listOf(5, 6, 7, 8)

    val GOLD = 0xFFFFC857.toInt()
    val MUTED = 0xFFB4BFD1.toInt()
    val CARD = 0xCC141C2E.toInt()
    val ITEM = 0xCC1C2740.toInt()
    val SEL = 0xFF1E8E5A.toInt()

    fun prefs(c: Context): SharedPreferences = c.getSharedPreferences("launcher", Context.MODE_PRIVATE)

    fun accent(p: SharedPreferences): Int =
        accents.getOrNull(p.getInt("accent_idx", 0))?.second ?: accents[0].second
}
