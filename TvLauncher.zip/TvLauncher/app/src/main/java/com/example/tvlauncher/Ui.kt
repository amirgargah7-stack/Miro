package com.example.tvlauncher

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.widget.TextView

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun Context.rounded(color: Int, r: Int): GradientDrawable {
    val g = GradientDrawable()
    g.setColor(color)
    g.cornerRadius = dp(r).toFloat()
    return g
}

fun Context.tv(s: String, sp: Float, color: Int, bold: Boolean = false): TextView {
    val t = TextView(this)
    t.text = s
    t.textSize = sp
    t.setTextColor(color)
    if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
    return t
}

// تلوين زر محدد (أخضر) أو عادي، مع احترام لون التركيز
fun Context.setSel(v: TextView, sel: Boolean) {
    v.tag = sel
    val acc = K.accent(K.prefs(this))
    v.background = rounded(if (v.isFocused) acc else if (sel) K.SEL else K.ITEM, 12)
}

fun Context.btn(label: String, sp: Float = 16f, hPad: Int = 14, onClick: () -> Unit): TextView {
    val acc = K.accent(K.prefs(this))
    val t = tv(label, sp, Color.WHITE, true)
    t.gravity = Gravity.CENTER
    t.isFocusable = true
    t.isClickable = true
    t.setPadding(dp(hPad), dp(8), dp(hPad), dp(8))
    t.background = rounded(K.ITEM, 12)
    t.setOnFocusChangeListener { v, f ->
        v.background = rounded(if (f) acc else if (v.tag == true) K.SEL else K.ITEM, 12)
    }
    t.setOnClickListener { onClick() }
    return t
}
