package com.example.tvlauncher

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.view.View

// أيقونة صغيرة ترمز لوقت الصلاة: 0 فجر، 1 ظهر، 2 عصر، 3 مغرب، 4 عشاء
class PrayerIconView(ctx: Context) : View(ctx) {
    var kind = 0
        set(value) {
            if (field != value) {
                field = value
                invalidate()
            }
        }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val cx = w / 2f
        val cy = height / 2f
        val r = w * 0.20f
        if (kind == 4) {
            p.style = Paint.Style.FILL
            p.color = 0xFFFFE082.toInt()
            val a = Path()
            a.addCircle(cx, cy, r * 1.3f, Path.Direction.CW)
            val b = Path()
            b.addCircle(cx + r * 0.75f, cy - r * 0.4f, r * 1.1f, Path.Direction.CW)
            a.op(b, Path.Op.DIFFERENCE)
            canvas.drawPath(a, p)
            return
        }
        val col = when (kind) {
            1 -> 0xFFFFD54F.toInt()
            2 -> 0xFFFFA726.toInt()
            else -> 0xFFFFB347.toInt()
        }
        val half = kind == 0 || kind == 3
        val cyy = if (half) cy + r * 0.55f else cy
        p.color = col
        p.style = Paint.Style.STROKE
        p.strokeWidth = w * 0.05f
        p.strokeCap = Paint.Cap.ROUND
        val n = if (half) 5 else 8
        for (i in 0 until n) {
            val ang = if (half) Math.PI + i * Math.PI / (n - 1) else i * 2 * Math.PI / n
            val x1 = cx + (r * 1.5f * Math.cos(ang)).toFloat()
            val y1 = cyy + (r * 1.5f * Math.sin(ang)).toFloat()
            val x2 = cx + (r * 2.0f * Math.cos(ang)).toFloat()
            val y2 = cyy + (r * 2.0f * Math.sin(ang)).toFloat()
            canvas.drawLine(x1, y1, x2, y2, p)
        }
        p.style = Paint.Style.FILL
        if (half) {
            canvas.save()
            canvas.clipRect(0f, 0f, w, cyy)
            canvas.drawCircle(cx, cyy, r, p)
            canvas.restore()
            p.style = Paint.Style.STROKE
            canvas.drawLine(cx - r * 2.0f, cyy, cx + r * 2.0f, cyy, p)
        } else {
            canvas.drawCircle(cx, cyy, r, p)
        }
    }
}
