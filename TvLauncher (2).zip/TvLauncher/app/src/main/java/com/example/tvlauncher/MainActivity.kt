package com.example.tvlauncher

import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var store: AppStore
    private lateinit var bgView: BackgroundView
    private lateinit var brandRow: LinearLayout
    private lateinit var tvGreeting: TextView
    private lateinit var clockView: TextClock
    private lateinit var divider: View
    private lateinit var tvDate: TextView
    private lateinit var tvWeather: TextView
    private lateinit var prayerCard: LinearLayout
    private lateinit var pcIcon: PrayerIconView
    private lateinit var pcName: TextView
    private lateinit var pcTime: TextView
    private lateinit var pcCd: TextView
    private val pcNames = ArrayList<TextView>()
    private val pcTimes = ArrayList<TextView>()
    private lateinit var tvFocusTitle: TextView
    private lateinit var dockFrame: FrameLayout
    private lateinit var shelf: View
    private lateinit var appList: RecyclerView
    private lateinit var gridLm: GridLayoutManager
    private val adapter = AppAdapter()
    private val handler = Handler(Looper.getMainLooper())
    private val five: List<Pair<String, String>> = K.prayers.filter { it.first != "Sunrise" }
    private var allApps: List<AppItem> = emptyList()
    private var rows: List<AppItem> = emptyList()
    private var ticks = 0

    // ---------- مقاسات الأرفف ----------
    private fun cols(): Int = K.colsOptions.getOrElse(prefs.getInt("cols_idx", 1)) { 5 }
    private fun cellW(c: Int): Int = (resources.displayMetrics.widthPixels - dp(40) * 2 - dp(20) * 2) / c
    private fun tileH(c: Int): Int = ((cellW(c) - dp(16)) * 9f / 16f).toInt()

    private fun glass(f: Boolean): GradientDrawable {
        val g = rounded(if (f) 0x55FFFFFF else 0x38FFFFFF, 26)
        g.setStroke(dp(if (f) 3 else 1), if (f) Color.WHITE else 0x44FFFFFF)
        return g
    }

    private fun focusRing(): GradientDrawable {
        val g = GradientDrawable()
        g.cornerRadius = dp(18).toFloat()
        g.setColor(Color.TRANSPARENT)
        g.setStroke(dp(3), Color.WHITE)
        return g
    }

    private fun pill(label: String, onClick: () -> Unit): TextView {
        val t = tv(label, 15f, Color.WHITE, true)
        t.gravity = Gravity.CENTER
        t.isFocusable = true
        t.isClickable = true
        t.setPadding(dp(22), dp(10), dp(22), dp(10))
        t.background = rounded(0x55FFFFFF, 30)
        t.setOnFocusChangeListener { v, f ->
            v.background = rounded(if (f) 0xEEFFFFFF.toInt() else 0x55FFFFFF, 30)
            (v as TextView).setTextColor(if (f) Color.BLACK else Color.WHITE)
        }
        t.setOnClickListener { onClick() }
        return t
    }

    private fun openSystem(action: String) {
        try {
            startActivity(Intent(action))
        } catch (e: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_SETTINGS))
            } catch (e2: Exception) {
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = K.prefs(this)
        store = AppStore(this)
        seedDefaults()
        bgView = BackgroundView(this)

        val content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.layoutDirection = View.LAYOUT_DIRECTION_LTR
        content.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(0x88000000.toInt(), 0x00000000, 0x00000000, 0xAA000000.toInt())
        )

        // ===== الرأس: (يسار) تحية + ساعة + تاريخ + طقس  |  (يمين) أزرار + بطاقة الأذان =====
        val header = LinearLayout(this)
        header.setPadding(dp(56), dp(26), dp(56), 0)

        val left = LinearLayout(this)
        left.orientation = LinearLayout.VERTICAL
        brandRow = LinearLayout(this)
        brandRow.gravity = Gravity.CENTER_VERTICAL
        val logo = ImageView(this)
        logo.setImageResource(R.drawable.ic_logo)
        brandRow.addView(logo, LinearLayout.LayoutParams(dp(34), dp(34)))
        val bn = tv("Miro Launcher TV", 14f, Color.WHITE, true)
        bn.setPadding(dp(10), 0, 0, 0)
        brandRow.addView(bn)
        left.addView(brandRow)
        tvGreeting = tv("", 15f, Color.WHITE, true)
        tvGreeting.letterSpacing = 0.12f
        left.addView(tvGreeting, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { topMargin = dp(14) })
        val clockRow = LinearLayout(this)
        clockRow.gravity = Gravity.CENTER_VERTICAL
        clockView = TextClock(this)
        clockView.textSize = 66f
        clockView.setTextColor(Color.WHITE)
        clockView.setTypeface(clockView.typeface, Typeface.BOLD)
        clockRow.addView(clockView)
        divider = View(this)
        divider.setBackgroundColor(0x66FFFFFF)
        clockRow.addView(divider, LinearLayout.LayoutParams(dp(2), dp(46)).apply {
            setMargins(dp(20), 0, dp(20), 0)
        })
        tvDate = tv("", 20f, Color.WHITE, true)
        clockRow.addView(tvDate)
        left.addView(clockRow)
        tvWeather = tv("", 16f, K.MUTED)
        left.addView(tvWeather, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { topMargin = dp(2) })
        header.addView(left, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))

        val right = LinearLayout(this)
        right.orientation = LinearLayout.VERTICAL
        right.gravity = Gravity.END
        val pills = LinearLayout(this)
        val pm = LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { setMargins(dp(5), 0, dp(5), 0) }
        pills.addView(pill("Wi-Fi") { openSystem(Settings.ACTION_WIFI_SETTINGS) }, pm)
        pills.addView(pill("النظام") { openSystem(Settings.ACTION_SETTINGS) },
            LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { setMargins(dp(5), 0, dp(5), 0) })
        pills.addView(pill("الإعدادات") { startActivity(Intent(this, SettingsActivity::class.java)) },
            LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { setMargins(dp(5), 0, dp(5), 0) })
        right.addView(pills)
        prayerCard = buildPrayerCard()
        right.addView(prayerCard, LinearLayout.LayoutParams(dp(400), WRAP_CONTENT).apply { topMargin = dp(16) })
        header.addView(right, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT))

        // ===== عنوان التطبيق المحدد + الرف =====
        tvFocusTitle = tv("", 46f, Color.WHITE, true)
        tvFocusTitle.setShadowLayer(10f, 0f, 3f, 0xAA000000.toInt())
        tvFocusTitle.setPadding(dp(60), 0, dp(60), dp(10))
        tvFocusTitle.maxLines = 1
        tvFocusTitle.ellipsize = TextUtils.TruncateAt.END

        dockFrame = FrameLayout(this)
        dockFrame.clipChildren = false
        shelf = View(this)
        val shelfBg = rounded(0x40FFFFFF, 30)
        shelfBg.setStroke(dp(1), 0x40FFFFFF)
        shelf.background = shelfBg
        dockFrame.addView(shelf, FrameLayout.LayoutParams(MATCH_PARENT, dp(120)))
        gridLm = GridLayoutManager(this, 5)
        appList = RecyclerView(this)
        appList.layoutManager = gridLm
        appList.adapter = adapter
        appList.clipToPadding = false
        appList.clipChildren = false
        appList.setPadding(dp(20), 0, dp(20), 0)
        appList.itemAnimator = null
        dockFrame.addView(appList, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT).apply { topMargin = dp(12) })

        content.addView(header, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        content.addView(View(this), LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        content.addView(tvFocusTitle, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        content.addView(dockFrame, LinearLayout.LayoutParams(MATCH_PARENT, dp(200)).apply {
            setMargins(dp(40), 0, dp(40), dp(10))
        })

        val frame = FrameLayout(this)
        frame.addView(bgView, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        frame.addView(content, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        setContentView(frame)
        applyDisplaySettings()
        renderStatic()
    }

    // ---------- بطاقة الأذان القادم ----------
    private fun buildPrayerCard(): LinearLayout {
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(22), dp(14), dp(22), dp(14))
        card.isFocusable = true
        card.isClickable = true
        card.background = glass(false)
        card.setOnFocusChangeListener { v, f -> v.background = glass(f) }
        card.setOnClickListener { showPrayerSheet() }

        val top = LinearLayout(this)
        top.gravity = Gravity.CENTER_VERTICAL
        pcIcon = PrayerIconView(this)
        top.addView(pcIcon, LinearLayout.LayoutParams(dp(64), dp(64)))
        top.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.END
        col.addView(tv("الأذان القادم", 12f, K.MUTED, true))
        pcName = tv("--", 38f, Color.WHITE, true)
        col.addView(pcName)
        val line = LinearLayout(this)
        line.gravity = Gravity.END or Gravity.CENTER_VERTICAL
        pcCd = tv("", 13f, K.MUTED, true)
        pcCd.setPadding(0, 0, dp(12), 0)
        pcTime = tv("--:--", 24f, K.GOLD, true)
        line.addView(pcCd)
        line.addView(pcTime)
        col.addView(line)
        top.addView(col)
        card.addView(top)

        val div = View(this)
        div.setBackgroundColor(0x33FFFFFF)
        card.addView(div, LinearLayout.LayoutParams(MATCH_PARENT, dp(1)).apply {
            topMargin = dp(8)
            bottomMargin = dp(8)
        })
        val row = LinearLayout(this)
        row.layoutDirection = View.LAYOUT_DIRECTION_RTL
        for (p in five) {
            val c = LinearLayout(this)
            c.orientation = LinearLayout.VERTICAL
            c.gravity = Gravity.CENTER_HORIZONTAL
            val n = tv(p.second, 12f, K.MUTED, true)
            n.gravity = Gravity.CENTER
            val t = tv("--:--", 13f, Color.WHITE, true)
            t.gravity = Gravity.CENTER
            c.addView(n)
            c.addView(t)
            pcNames.add(n)
            pcTimes.add(t)
            row.addView(c, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        }
        card.addView(row)
        return card
    }

    // أول تشغيل: نسخ صور الخلفية الجاهزة إلى مخزن التطبيق
    private fun seedDefaults() {
        if (prefs.getBoolean("bg_seeded", false)) return
        try {
            val names = assets.list("defaults") ?: emptyArray()
            for (n in names) {
                assets.open("defaults/$n").use { input ->
                    java.io.FileOutputStream(java.io.File(bgDir(this), "bg_0_$n")).use { out ->
                        input.copyTo(out)
                    }
                }
            }
        } catch (e: Exception) {
        }
        prefs.edit().putBoolean("bg_seeded", true).apply()
    }

    override fun onResume() {
        super.onResume()
        bgView.reload(prefs)
        applyDisplaySettings()
        renderStatic()
        loadApps()
        refreshData()
        handler.removeCallbacks(ticker)
        handler.post(ticker)
    }

    override fun onPause() {
        super.onPause()
        bgView.stop()
        handler.removeCallbacks(ticker)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {}

    private val ticker = object : Runnable {
        override fun run() {
            updateCountdown()
            ticks++
            if (ticks % 1800 == 0) {
                refreshData()
            } else if (ticks % 60 == 0) {
                if (prefs.getString("p_date", "") != todayStr()) refreshData()
                tvDate.text = dateText()
                tvGreeting.text = greeting()
            }
            handler.postDelayed(this, 1000)
        }
    }

    private fun applyDisplaySettings() {
        val f = if (prefs.getBoolean("clock_24", true)) "HH:mm" else "h:mm a"
        clockView.format12Hour = f
        clockView.format24Hour = f
        val showDate = prefs.getBoolean("show_date", true)
        tvDate.visibility = if (showDate) View.VISIBLE else View.GONE
        divider.visibility = if (showDate) View.VISIBLE else View.GONE
        brandRow.visibility = if (prefs.getBoolean("show_brand", true)) View.VISIBLE else View.GONE
        prayerCard.visibility = if (prefs.getBoolean("show_next", true)) View.VISIBLE else View.GONE
        tvWeather.visibility = if (prefs.getBoolean("show_weather", true)) View.VISIBLE else View.GONE
        val c = cols()
        if (gridLm.spanCount != c) gridLm.spanCount = c
        val rowPx = tileH(c) + dp(12)
        shelf.layoutParams.height = rowPx + dp(24)
        dockFrame.layoutParams.height = rowPx + dp(24) + (rowPx * 0.6f).toInt() + dp(6)
        shelf.requestLayout()
        dockFrame.requestLayout()
    }

    // ===== الشبكة: الموقع + الصلاة + الطقس =====
    private fun refreshData() {
        thread {
            if ((prefs.getString("loc_mode", "auto") ?: "auto") == "auto") {
                ipLocation()?.let {
                    prefs.edit()
                        .putString("lat", it.first.toString())
                        .putString("lon", it.second.toString())
                        .putString("city", it.third)
                        .apply()
                }
            }
            val lat = prefs.getString("lat", null)
            val lon = prefs.getString("lon", null)
            if (lat != null && lon != null) {
                fetchPrayers(lat, lon)
                fetchWeather(lat, lon)
            }
            runOnUiThread { renderStatic() }
        }
    }

    private fun todayStr(): String = SimpleDateFormat("dd-MM-yyyy", Locale.US).format(Date())

    private fun fetchPrayers(lat: String, lon: String) {
        val today = todayStr()
        val method = prefs.getInt("calc_method", -1)
        val school = if (prefs.getBoolean("asr_hanafi", false)) 1 else 0
        val loc = "$lat,$lon,$method,$school"
        if (prefs.getString("p_date", "") == today && prefs.getString("p_loc", "") == loc &&
            prefs.contains("p_Fajr")
        ) return
        var url = "https://api.aladhan.com/v1/timings/$today?latitude=$lat&longitude=$lon&school=$school"
        if (method >= 0) url += "&method=$method"
        val body = httpGet(url) ?: return
        try {
            val t = JSONObject(body).getJSONObject("data").getJSONObject("timings")
            val e = prefs.edit()
            for (p in K.prayers) e.putString("p_" + p.first, t.getString(p.first).take(5))
            e.putString("p_date", today).putString("p_loc", loc).apply()
        } catch (ex: Exception) {
        }
    }

    private fun fetchWeather(lat: String, lon: String) {
        val body = httpGet(
            "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,weather_code"
        ) ?: return
        try {
            val c = JSONObject(body).getJSONObject("current")
            prefs.edit()
                .putString("temp", c.getDouble("temperature_2m").toString())
                .putInt("wcode", c.getInt("weather_code"))
                .apply()
        } catch (ex: Exception) {
        }
    }

    // ===== العرض =====
    private fun dateText(): String =
        SimpleDateFormat("EEEE d MMMM", Locale.forLanguageTag("ar-u-nu-latn")).format(Date())

    private fun greeting(): String {
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return when {
            h in 5..11 -> "صباح الخير"
            h in 12..16 -> "نهارك سعيد"
            h in 17..21 -> "مساء الخير"
            else -> "ليلة سعيدة"
        }
    }

    private fun weatherText(code: Int): String = when (code) {
        0 -> "صافٍ"
        1, 2 -> "غائم جزئياً"
        3 -> "غائم"
        45, 48 -> "ضباب"
        in 51..67, in 80..82 -> "مطر"
        in 71..77, 85, 86 -> "ثلج"
        in 95..99 -> "عاصفة رعدية"
        else -> ""
    }

    private fun renderStatic() {
        tvGreeting.text = greeting()
        tvDate.text = dateText()
        val temp = prefs.getString("temp", null)?.toDoubleOrNull()
        var tempText = ""
        if (temp != null) {
            val useF = prefs.getBoolean("temp_f", false)
            val v = if (useF) temp * 9.0 / 5.0 + 32.0 else temp
            tempText = "\u200E" + Math.round(v) + (if (useF) "°F" else "°C")
        }
        val city = prefs.getString("city", "") ?: ""
        val desc = if (temp != null) weatherText(prefs.getInt("wcode", 0)) else ""
        tvWeather.text = listOf(tempText, desc, city).filter { it.isNotEmpty() }.joinToString(" • ")
        for (i in five.indices) {
            val c = PT.cal(prefs, five[i].first)
            pcTimes[i].text = if (c != null) PT.fmt(prefs, c) else "--:--"
        }
        updateCountdown()
    }

    private fun cdText(sec: Long): String {
        val h = sec / 3600
        val m = (sec % 3600) / 60
        val s = sec % 60
        return if (h > 0) "بعد $h س $m د" else "بعد $m د $s ث"
    }

    private fun updateCountdown() {
        val np = PT.next(prefs)
        if (np == null) {
            pcName.text = "—"
            pcTime.text = ""
            pcCd.text = "جارٍ التحميل…"
            return
        }
        val key = K.prayers[np.first].first
        pcName.text = K.prayers[np.first].second
        pcTime.text = PT.fmt(prefs, np.second)
        val diff = ((np.second.timeInMillis - System.currentTimeMillis()) / 1000).coerceAtLeast(0)
        pcCd.text = cdText(diff)
        pcIcon.kind = when (key) {
            "Fajr" -> 0
            "Dhuhr" -> 1
            "Asr" -> 2
            "Maghrib" -> 3
            else -> 4
        }
        for (i in five.indices) {
            val hi = five[i].first == key
            pcNames[i].setTextColor(if (hi) K.GOLD else K.MUTED)
            pcTimes[i].setTextColor(if (hi) K.GOLD else Color.WHITE)
        }
    }

    private fun showPrayerSheet() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.layoutDirection = View.LAYOUT_DIRECTION_RTL
        box.setPadding(dp(24), dp(18), dp(24), dp(10))
        box.setBackgroundColor(0xFF141C2E.toInt())
        box.addView(tv("أوقات الصلاة  •  اضبط كل أذان وحده", 18f, K.GOLD, true))
        box.addView(
            buildPrayerRows(this, prefs) { renderStatic() },
            LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(8) }
        )
        val dlg = AlertDialog.Builder(this).setView(box).setPositiveButton("تم", null).create()
        dlg.show()
        dlg.window?.setLayout(dp(760), ViewGroup.LayoutParams.WRAP_CONTENT)
    }

    // ===== التطبيقات =====
    private fun loadApps() {
        thread {
            val items = store.loadAll()
            runOnUiThread {
                allApps = items
                applyRows(true)
                if (!appList.hasFocus()) focusFirstApp()
            }
        }
    }

    private fun buildRows(): List<AppItem> {
        val s = store.sections(allApps)
        return s.pinned + s.rest
    }

    private fun applyRows(rebuildViews: Boolean) {
        rows = buildRows()
        if (rebuildViews) appList.adapter = adapter else adapter.notifyDataSetChanged()
        if (tvFocusTitle.text.isNullOrEmpty() && rows.isNotEmpty()) tvFocusTitle.text = rows[0].label
    }

    private fun focusPosition(pos: Int, delay: Long = 250) {
        if (pos < 0) return
        appList.scrollToPosition(pos)
        appList.postDelayed({ gridLm.findViewByPosition(pos)?.requestFocus() }, delay)
    }

    private fun focusFirstApp() {
        if (rows.isNotEmpty()) focusPosition(0, 400)
    }

    private fun posOf(pkg: String): Int = rows.indexOfFirst { it.pkg == pkg }

    private fun showAppMenu(item: AppItem) {
        val pinned = store.isPinned(item.pkg)
        val options = arrayOf(
            if (pinned) "إلغاء التثبيت من المفضلة" else "تثبيت في المفضلة",
            "تحريك خطوة للأمام",
            "تحريك خطوة للخلف",
            "نقل إلى البداية",
            "إخفاء التطبيق",
            "إدارة كل التطبيقات…"
        )
        AlertDialog.Builder(this)
            .setTitle(item.label)
            .setItems(options) { _, which ->
                when (which) {
                    0 -> {
                        store.togglePin(item.pkg)
                        applyRows(false)
                        focusPosition(posOf(item.pkg))
                    }
                    1 -> moveApp(item, -1, false)
                    2 -> moveApp(item, 1, false)
                    3 -> moveApp(item, 0, true)
                    4 -> {
                        val before = posOf(item.pkg)
                        store.hide(item.pkg)
                        applyRows(false)
                        focusPosition(minOf(before, rows.size - 1))
                    }
                    else -> startActivity(Intent(this, SettingsActivity::class.java).putExtra("page", 5))
                }
            }
            .show()
    }

    private fun moveApp(item: AppItem, delta: Int, toStart: Boolean) {
        store.move(allApps, item.pkg, delta, toStart)
        applyRows(false)
        focusPosition(posOf(item.pkg))
    }

    private inner class TileVH(
        val tile: FrameLayout, val banner: ImageView, val icon: ImageView, val label: TextView
    ) : RecyclerView.ViewHolder(tile)

    private inner class AppAdapter : RecyclerView.Adapter<TileVH>() {

        override fun getItemCount() = rows.size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TileVH {
            val h = tileH(cols())
            val tile = FrameLayout(parent.context)
            tile.layoutParams = RecyclerView.LayoutParams(MATCH_PARENT, h).apply {
                setMargins(dp(8), dp(6), dp(8), dp(6))
            }
            tile.isFocusable = true
            tile.background = rounded(0xFF2A3350.toInt(), 18)
            tile.clipToOutline = true
            tile.outlineProvider = ViewOutlineProvider.BACKGROUND
            val banner = ImageView(parent.context)
            banner.scaleType = ImageView.ScaleType.CENTER_CROP
            tile.addView(banner, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
            val icon = ImageView(parent.context)
            icon.scaleType = ImageView.ScaleType.FIT_CENTER
            val isz = (h * 0.5f).toInt()
            tile.addView(icon, FrameLayout.LayoutParams(isz, isz, Gravity.CENTER).apply {
                bottomMargin = dp(12)
            })
            val label = TextView(parent.context)
            label.textSize = 12f
            label.setTextColor(Color.WHITE)
            label.maxLines = 1
            label.ellipsize = TextUtils.TruncateAt.END
            label.gravity = Gravity.CENTER
            label.setPadding(dp(6), dp(4), dp(6), dp(4))
            label.setBackgroundColor(0x66000000)
            tile.addView(label, FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT, Gravity.BOTTOM))
            return TileVH(tile, banner, icon, label)
        }

        override fun onBindViewHolder(h: TileVH, position: Int) {
            val item = rows[position]
            if (item.banner != null) {
                h.banner.setImageDrawable(item.banner)
                h.banner.visibility = View.VISIBLE
                h.icon.visibility = View.GONE
                h.label.visibility = View.GONE
            } else {
                h.banner.visibility = View.GONE
                h.icon.setImageDrawable(item.icon)
                h.icon.visibility = View.VISIBLE
                h.label.text = item.label
                h.label.visibility = View.VISIBLE
            }
            h.tile.setOnFocusChangeListener { v, f ->
                v.animate().scaleX(if (f) 1.1f else 1f).scaleY(if (f) 1.1f else 1f).setDuration(140).start()
                v.elevation = if (f) dp(16).toFloat() else 0f
                (v as FrameLayout).foreground = if (f) focusRing() else null
                if (f) {
                    tvFocusTitle.text = item.label
                    val dy = v.top - dp(6)
                    if (dy != 0) appList.smoothScrollBy(0, dy)
                }
            }
            h.tile.setOnClickListener {
                val i = Intent(Intent.ACTION_MAIN)
                    .setComponent(ComponentName(item.pkg, item.cls))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(i)
            }
            h.tile.setOnLongClickListener {
                showAppMenu(item)
                true
            }
        }
    }
}
