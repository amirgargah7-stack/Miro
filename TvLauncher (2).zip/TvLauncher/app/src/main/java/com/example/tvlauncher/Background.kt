package com.example.tvlauncher

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import java.io.File
import kotlin.concurrent.thread
import kotlin.random.Random

fun bgDir(ctx: Context): File = File(ctx.filesDir, "bg").apply { mkdirs() }

fun bgFiles(ctx: Context): List<File> =
    (bgDir(ctx).listFiles() ?: emptyArray<File>()).filter { it.extension == "jpg" }.sortedBy { it.name }

// خلفية متحركة: عرض صور مع انتقال تدريجي وتقريب بطيء، أو توهّج ألوان متحرك إن لم توجد صور
class BackgroundView(private val ctx: Context) : FrameLayout(ctx) {
    private val palettes: Array<IntArray> = arrayOf(
        intArrayOf(0xFFC80F2E.toInt(), 0xFF5A0A18.toInt(), 0xFF0A0306.toInt()),
        intArrayOf(0xFF1F5BFF.toInt(), 0xFF0E2A6B.toInt(), 0xFF040712.toInt()),
        intArrayOf(0xFF14A860.toInt(), 0xFF0A4D2C.toInt(), 0xFF030A06.toInt()),
        intArrayOf(0xFF8A2BE2.toInt(), 0xFF3A1470.toInt(), 0xFF080410.toInt()),
        intArrayOf(0xFF3A3F4B.toInt(), 0xFF1A1D24.toInt(), 0xFF050608.toInt())
    )
    private val mp = ViewGroup.LayoutParams.MATCH_PARENT
    private val gradientView = View(ctx)
    private val a = ImageView(ctx)
    private val b = ImageView(ctx)
    private val dim = View(ctx)
    private val handler = Handler(Looper.getMainLooper())
    private val grad = GradientDrawable()
    private var radiusBase = 1200f
    private var colorAnim: ValueAnimator? = null
    private var files: List<File> = emptyList()
    private var index = 0
    private var showingA = true
    private var intervalMs = 15000L
    private var token = 0

    init {
        grad.gradientType = GradientDrawable.RADIAL_GRADIENT
        grad.colors = palettes[0]
        grad.setGradientCenter(0.4f, 0.45f)
        grad.gradientRadius = radiusBase
        gradientView.background = grad
        a.scaleType = ImageView.ScaleType.CENTER_CROP
        b.scaleType = ImageView.ScaleType.CENTER_CROP
        a.alpha = 0f
        b.alpha = 0f
        addView(gradientView, FrameLayout.LayoutParams(mp, mp))
        addView(a, FrameLayout.LayoutParams(mp, mp))
        addView(b, FrameLayout.LayoutParams(mp, mp))
        addView(dim, FrameLayout.LayoutParams(mp, mp))
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        radiusBase = w * 0.85f
        grad.gradientRadius = radiusBase
    }

    fun reload(prefs: SharedPreferences) {
        stop()
        val on = prefs.getBoolean("bg_on", true)
        intervalMs = prefs.getInt("bg_interval", 15) * 1000L
        val dimPct = prefs.getInt("bg_dim", 35).coerceIn(0, 90)
        files = bgFiles(ctx)
        a.alpha = 0f
        b.alpha = 0f
        a.setImageDrawable(null)
        b.setImageDrawable(null)
        if (!on || files.isEmpty()) {
            grad.colors = palettes[prefs.getInt("grad_idx", 0).coerceIn(0, palettes.size - 1)]
            gradientView.visibility = View.VISIBLE
            dim.setBackgroundColor(Color.TRANSPARENT)
            startGradient()
        } else {
            gradientView.visibility = View.GONE
            dim.setBackgroundColor(Color.argb(dimPct * 255 / 100, 0, 0, 0))
            index = 0
            showNext()
        }
    }

    fun stop() {
        token++
        handler.removeCallbacksAndMessages(null)
        a.animate().cancel()
        b.animate().cancel()
        colorAnim?.cancel()
        colorAnim = null
    }

    override fun onDetachedFromWindow() {
        stop()
        super.onDetachedFromWindow()
    }

    private fun startGradient() {
        colorAnim?.cancel()
        val anim = ValueAnimator.ofFloat(0f, 1f)
        anim.duration = 14000
        anim.repeatCount = ValueAnimator.INFINITE
        anim.repeatMode = ValueAnimator.REVERSE
        anim.addUpdateListener {
            val f = it.animatedFraction
            grad.setGradientCenter(0.30f + 0.25f * f, 0.40f + 0.12f * (1f - f))
            grad.gradientRadius = radiusBase * (0.85f + 0.2f * f)
        }
        anim.start()
        colorAnim = anim
    }

    private fun showNext() {
        val myToken = token
        if (files.isEmpty()) return
        val f = files[index % files.size]
        index++
        thread {
            val opts = BitmapFactory.Options()
            opts.inPreferredConfig = Bitmap.Config.RGB_565
            val bmp: Bitmap? = try {
                BitmapFactory.decodeFile(f.absolutePath, opts)
            } catch (e: Throwable) {
                null
            }
            handler.post {
                if (myToken == token) {
                    if (bmp != null) crossfadeTo(bmp)
                    handler.postDelayed({
                        if (myToken == token) showNext()
                    }, intervalMs)
                }
            }
        }
    }

    private fun crossfadeTo(bmp: Bitmap) {
        val incoming = if (showingA) b else a
        val outgoing = if (showingA) a else b
        showingA = !showingA
        incoming.animate().cancel()
        incoming.setImageBitmap(bmp)
        incoming.alpha = 0f
        incoming.scaleX = 1f
        incoming.scaleY = 1f
        incoming.translationX = 0f
        incoming.translationY = 0f
        incoming.bringToFront()
        dim.bringToFront()
        ObjectAnimator.ofFloat(incoming, View.ALPHA, 0f, 1f).setDuration(1500).start()
        val dx = Random.nextInt(-40, 41).toFloat()
        val dy = Random.nextInt(-25, 26).toFloat()
        incoming.animate()
            .scaleX(1.12f).scaleY(1.12f)
            .translationX(dx).translationY(dy)
            .setDuration(intervalMs + 3000)
            .setInterpolator(LinearInterpolator())
            .start()
        handler.postDelayed({
            outgoing.alpha = 0f
            outgoing.setImageDrawable(null)
        }, 1700)
    }
}
