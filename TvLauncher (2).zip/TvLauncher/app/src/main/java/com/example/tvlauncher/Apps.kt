package com.example.tvlauncher

import android.content.Context
import android.content.Intent
import android.graphics.drawable.Drawable

class AppItem(val label: String, val icon: Drawable, val pkg: String, val cls: String, val banner: Drawable? = null)

class AppSections(val pinned: List<AppItem>, val rest: List<AppItem>, val hidden: List<AppItem>)

// تخزين ترتيب التطبيقات: المفضلة + الترتيب + المخفية
class AppStore(private val ctx: Context) {
    private val prefs = K.prefs(ctx)

    fun loadAll(): List<AppItem> {
        val pm = ctx.packageManager
        var intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
        val tvApps = pm.queryIntentActivities(intent, 0)
        intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val all = (tvApps + pm.queryIntentActivities(intent, 0))
            .distinctBy { it.activityInfo.packageName }
            .filter { it.activityInfo.packageName != ctx.packageName }
        return all.map {
            val ai = it.activityInfo
            val bn: Drawable? = try {
                ai.loadBanner(pm)
            } catch (e: Exception) {
                null
            }
            AppItem(it.loadLabel(pm).toString(), it.loadIcon(pm), ai.packageName, ai.name, bn)
        }.sortedBy { it.label.lowercase() }
    }

    private fun list(key: String): MutableList<String> =
        (prefs.getString(key, "") ?: "").split("\n").filter { it.isNotEmpty() }.toMutableList()

    private fun save(key: String, l: List<String>) {
        prefs.edit().putString(key, l.joinToString("\n")).apply()
    }

    fun hidden(): Set<String> = prefs.getStringSet("app_hidden", emptySet()) ?: emptySet()

    fun isPinned(pkg: String): Boolean = list("app_pinned").contains(pkg)

    fun sections(all: List<AppItem>): AppSections {
        val hid = hidden()
        val pins = list("app_pinned")
        val order = list("app_order")
        val byPkg = all.associateBy { it.pkg }
        val pinned = pins.mapNotNull { byPkg[it] }.filter { it.pkg !in hid }
        val pinSet = pinned.map { it.pkg }.toSet()
        val rest = all.filter { it.pkg !in hid && it.pkg !in pinSet }.sortedWith(
            compareBy<AppItem>({
                val i = order.indexOf(it.pkg)
                if (i < 0) Int.MAX_VALUE else i
            }, { it.label.lowercase() })
        )
        val hiddenApps = all.filter { it.pkg in hid }
        return AppSections(pinned, rest, hiddenApps)
    }

    fun togglePin(pkg: String) {
        val pins = list("app_pinned")
        if (pins.contains(pkg)) {
            pins.remove(pkg)
        } else {
            pins.add(pkg)
            show(pkg)
        }
        save("app_pinned", pins)
    }

    // delta: -1 للأمام، +1 للخلف
    fun move(all: List<AppItem>, pkg: String, delta: Int, toStart: Boolean) {
        val s = sections(all)
        if (s.pinned.any { it.pkg == pkg }) {
            val l = s.pinned.map { it.pkg }.toMutableList()
            reposition(l, pkg, delta, toStart)
            save("app_pinned", l)
        } else {
            val l = s.rest.map { it.pkg }.toMutableList()
            reposition(l, pkg, delta, toStart)
            save("app_order", l)
        }
    }

    private fun reposition(l: MutableList<String>, pkg: String, delta: Int, toStart: Boolean) {
        val i = l.indexOf(pkg)
        if (i < 0) return
        l.removeAt(i)
        val ni = if (toStart) 0 else (i + delta).coerceIn(0, l.size)
        l.add(ni, pkg)
    }

    fun hide(pkg: String) {
        val s = HashSet<String>(hidden())
        s.add(pkg)
        prefs.edit().putStringSet("app_hidden", s).apply()
    }

    fun show(pkg: String) {
        val s = HashSet<String>(hidden())
        s.remove(pkg)
        prefs.edit().putStringSet("app_hidden", s).apply()
    }

    fun showAll() {
        prefs.edit().remove("app_hidden").apply()
    }

    fun resetOrder() {
        prefs.edit().remove("app_order").remove("app_pinned").apply()
    }
}
