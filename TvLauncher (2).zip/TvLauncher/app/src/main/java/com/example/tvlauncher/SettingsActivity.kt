package com.example.tvlauncher

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.location.Location
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.URLEncoder
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.tan

private class Place(val name: String, val admin: String, val country: String, val lat: Double, val lon: Double)

class SettingsActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var store: AppStore
    private lateinit var content: FrameLayout
    private val catBtns = ArrayList<TextView>()
    private val pages = HashMap<Int, View>()
    private val catNames = listOf(
        "الموقع والخريطة", "أوقات الصلاة", "الطقس", "الوقت والعرض", "الخلفية", "التطبيقات", "حول"
    )
    private var current = -1

    // الموقع
    private lateinit var tvLocInfo: TextView
    private lateinit var tvStatus: TextView
    private lateinit var mapView: ImageView
    private lateinit var cityEdit: EditText
    private lateinit var resultsBox: LinearLayout
    private val modeBtns = LinkedHashMap<String, TextView>()

    // الخلفية
    private lateinit var bgStatus: TextView
    private lateinit var grid: GridLayout
    private lateinit var btnOn: TextView
    private lateinit var tvDim: TextView
    private val intervalBtns = LinkedHashMap<Int, TextView>()

    // التطبيقات
    private lateinit var appListBox: LinearLayout
    private var manageAll: List<AppItem> = emptyList()

    // ---------- أدوات بناء الواجهة ----------
    private fun column(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(22), dp(18), dp(22), dp(18))
        return c
    }

    private fun wrap(col: LinearLayout): View {
        val s = ScrollView(this)
        s.isFillViewport = true
        s.background = rounded(K.CARD, 18)
        s.addView(col)
        return s
    }

    private fun LinearLayout.add(v: View, top: Int = 10) {
        addView(v, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(top) })
    }

    private fun title(s: String): TextView = tv(s, 24f, Color.WHITE, true)
    private fun hint(s: String): TextView = tv(s, 13f, K.MUTED)

    private fun rowOf(vararg views: View): LinearLayout {
        val r = LinearLayout(this)
        for (v in views) {
            r.addView(v, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f).apply {
                setMargins(dp(4), dp(4), dp(4), dp(4))
            })
        }
        return r
    }

    private fun toggle(label: String, key: String, def: Boolean, after: () -> Unit = {}): View {
        val row = LinearLayout(this)
        row.gravity = Gravity.CENTER_VERTICAL
        lateinit var b: TextView
        fun upd(on: Boolean) {
            b.text = if (on) "مفعّل" else "معطّل"
            setSel(b, on)
        }
        b = btn("", 16f, 24) {
            val nv = !prefs.getBoolean(key, def)
            prefs.edit().putBoolean(key, nv).apply()
            upd(nv)
            after()
        }
        upd(prefs.getBoolean(key, def))
        row.addView(tv(label, 17f, Color.WHITE), LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        row.addView(b, LinearLayout.LayoutParams(dp(130), WRAP_CONTENT))
        return row
    }

    private fun choice(label: String, options: List<String>, get: () -> Int, set: (Int) -> Unit): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.addView(tv(label, 17f, Color.WHITE))
        val chips = ArrayList<TextView>()
        fun upd() {
            val cur = get()
            for ((i, c) in chips.withIndex()) setSel(c, i == cur)
        }
        var base = 0
        for (chunk in options.chunked(3)) {
            val row = LinearLayout(this)
            for ((k, o) in chunk.withIndex()) {
                val idx = base + k
                val c = btn(o, 15f, 12) {
                    set(idx)
                    upd()
                }
                chips.add(c)
                row.addView(c, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f).apply {
                    setMargins(dp(4), dp(6), dp(4), dp(2))
                })
            }
            for (k in chunk.size until 3) row.addView(View(this), LinearLayout.LayoutParams(0, 0, 1f))
            col.addView(row, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
            base += chunk.size
        }
        upd()
        return col
    }

    private fun firstFocusable(v: View): View? {
        if (v.visibility != View.VISIBLE) return null
        if ((v.isClickable || v is EditText) && v.isFocusable) return v
        if (v is ViewGroup) {
            for (i in 0 until v.childCount) {
                val r = firstFocusable(v.getChildAt(i))
                if (r != null) return r
            }
        }
        return null
    }

    // ---------- الشاشة ----------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = K.prefs(this)
        store = AppStore(this)
        val acc = K.accent(prefs)

        val root = LinearLayout(this)
        root.layoutDirection = View.LAYOUT_DIRECTION_RTL
        root.setBackgroundColor(0xFF0B1220.toInt())
        root.setPadding(dp(32), dp(20), dp(32), dp(20))

        val cats = LinearLayout(this)
        cats.orientation = LinearLayout.VERTICAL
        cats.setPadding(dp(16), dp(16), dp(16), dp(16))
        cats.background = rounded(K.CARD, 18)
        cats.addView(tv("الإعدادات", 26f, Color.WHITE, true))
        for ((i, name) in catNames.withIndex()) {
            val b = btn(name, 19f, 22) {
                val p = pages[i]
                val f = if (p != null) firstFocusable(p) else null
                if (f != null) f.requestFocus()
            }
            b.setOnFocusChangeListener { v, f ->
                v.background = rounded(if (f) acc else if (v.tag == true) K.SEL else K.ITEM, 12)
                if (f) showPage(i)
            }
            catBtns.add(b)
            cats.addView(b, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(8) })
        }
        root.addView(cats, LinearLayout.LayoutParams(dp(270), MATCH_PARENT))
        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(0, MATCH_PARENT, 1f).apply { setMargins(dp(16), 0, 0, 0) })
        setContentView(root)

        val start = intent.getIntExtra("page", 0).coerceIn(0, catNames.size - 1)
        showPage(start)
        catBtns[start].requestFocus()
    }

    private fun showPage(i: Int) {
        if (i == current) return
        current = i
        content.removeAllViews()
        var p = pages[i]
        if (p == null) {
            p = buildPage(i)
            pages[i] = p
        }
        content.addView(p, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        for ((j, b) in catBtns.withIndex()) setSel(b, j == i)
    }

    private fun rebuildPage(i: Int) {
        pages.remove(i)
        current = -1
        showPage(i)
    }

    private fun buildPage(i: Int): View = when (i) {
        0 -> pageLocation()
        1 -> pagePrayer()
        2 -> pageWeather()
        3 -> pageDisplay()
        4 -> pageBackground()
        5 -> pageApps()
        else -> pageAbout()
    }

    // ================= الطقس / الوقت / الصلاة / حول =================
    private fun pageWeather(): View {
        val col = column()
        col.add(title("الطقس"), 0)
        col.add(toggle("إظهار الطقس في الشريط العلوي", "show_weather", true), 16)
        col.add(choice("وحدة الحرارة", listOf("سيلسيوس °C", "فهرنهايت °F"),
            { if (prefs.getBoolean("temp_f", false)) 1 else 0 },
            { i -> prefs.edit().putBoolean("temp_f", i == 1).apply() }), 18)
        col.add(hint("يُحدَّث الطقس تلقائياً كل نصف ساعة حسب موقعك المحدد."), 14)
        return wrap(col)
    }

    private fun pageDisplay(): View {
        val col = column()
        col.add(title("الوقت والعرض"), 0)
        col.add(choice("نظام الساعة", listOf("24 ساعة", "12 ساعة"),
            { if (prefs.getBoolean("clock_24", true)) 0 else 1 },
            { i -> prefs.edit().putBoolean("clock_24", i == 0).apply() }), 16)
        col.add(toggle("إظهار التاريخ", "show_date", true), 16)
        col.add(toggle("إظهار الشعار والاسم", "show_brand", true), 12)
        col.add(choice("لون التحديد", K.accents.map { it.first },
            { prefs.getInt("accent_idx", 0) },
            { i -> prefs.edit().putInt("accent_idx", i).apply() }), 18)
        col.add(hint("يتغير لون التحديد في الأزرار عند فتح الإعدادات من جديد."), 8)
        return wrap(col)
    }

    private fun pagePrayer(): View {
        val col = column()
        col.add(title("أوقات الصلاة"), 0)
        col.add(toggle("إظهار الأذان القادم في الشريط العلوي", "show_next", true), 16)
        col.add(choice("طريقة حساب الأوقات", K.methods.map { it.first },
            { K.methods.indexOfFirst { m -> m.second == prefs.getInt("calc_method", -1) }.coerceAtLeast(0) },
            { i -> prefs.edit().putInt("calc_method", K.methods[i].second).remove("p_date").apply() }), 18)
        col.add(choice("حساب وقت العصر", listOf("شافعي (القياسي)", "حنفي"),
            { if (prefs.getBoolean("asr_hanafi", false)) 1 else 0 },
            { i -> prefs.edit().putBoolean("asr_hanafi", i == 1).remove("p_date").apply() }), 14)
        col.add(hint("بعد تغيير الطريقة تُحدَّث الأوقات تلقائياً عند الرجوع للشاشة الرئيسية."), 8)
        col.add(tv("ضبط كل أذان على حدة (بالدقائق)", 18f, K.GOLD, true), 20)
        col.add(buildPrayerRows(this, prefs) {}, 6)
        col.add(btn("إعادة ضبط كل الأذان", 15f, 18) {
            for (p in K.prayers) PT.setOffset(prefs, p.first, 0)
            rebuildPage(1)
        }, 16)
        return wrap(col)
    }

    private fun pageAbout(): View {
        val col = column()
        col.add(title("حول"), 0)
        col.add(tv("Miro Launcher TV", 22f, Color.WHITE, true), 16)
        col.add(hint("واجهة أندرويد تي في خفيفة بأسلوب Apple TV • الإصدار 2.0"), 6)
        col.add(hint("الخرائط © OpenStreetMap • الطقس Open-Meteo • الأذان Aladhan"), 6)
        col.add(btn("إعادة ضبط كل الإعدادات", 16f, 22) {
            AlertDialog.Builder(this)
                .setTitle("إعادة ضبط كل الإعدادات؟")
                .setMessage("ستعود كل الإعدادات إلى الوضع الافتراضي (الصور المضافة تبقى).")
                .setPositiveButton("نعم") { _, _ ->
                    val seeded = prefs.getBoolean("bg_seeded", false)
                    prefs.edit().clear().putBoolean("bg_seeded", seeded).apply()
                    recreate()
                }
                .setNegativeButton("إلغاء", null)
                .show()
        }, 24)
        return wrap(col)
    }

    // ================= الموقع والخريطة =================
    private fun pageLocation(): View {
        val col = column()
        col.add(title("الموقع والخريطة"), 0)
        tvLocInfo = tv("", 15f, K.MUTED)
        col.add(tvLocInfo, 10)

        val auto = btn("تلقائي") { setAuto() }
        val gps = btn("GPS") { useGps() }
        val manual = btn("يدوي") {
            status("اكتب اسم مدينتك ثم اضغط بحث")
            cityEdit.requestFocus()
        }
        modeBtns["auto"] = auto
        modeBtns["gps"] = gps
        modeBtns["manual"] = manual
        col.add(rowOf(auto, gps, manual))

        cityEdit = EditText(this)
        cityEdit.hint = "اكتب اسم المدينة (مثال: باتنة)"
        cityEdit.setHintTextColor(K.MUTED)
        cityEdit.setTextColor(Color.WHITE)
        cityEdit.textSize = 18f
        cityEdit.setSingleLine(true)
        cityEdit.imeOptions = EditorInfo.IME_ACTION_SEARCH
        cityEdit.background = rounded(K.ITEM, 12)
        cityEdit.setPadding(dp(14), dp(10), dp(14), dp(10))
        cityEdit.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_SEARCH) {
                search()
                true
            } else {
                false
            }
        }
        col.add(cityEdit)
        col.add(btn("بحث") { search() })
        tvStatus = tv("", 15f, K.GOLD)
        col.add(tvStatus)
        resultsBox = LinearLayout(this)
        resultsBox.orientation = LinearLayout.VERTICAL
        col.add(resultsBox)

        mapView = ImageView(this)
        mapView.scaleType = ImageView.ScaleType.FIT_CENTER
        mapView.background = rounded(K.ITEM, 12)
        col.addView(mapView, LinearLayout.LayoutParams(MATCH_PARENT, dp(260)).apply { topMargin = dp(10) })
        col.add(tv("© OpenStreetMap contributors", 11f, K.MUTED), 4)
        refreshLocInfo()
        showSavedMap()
        return wrap(col)
    }

    private fun refreshLocInfo() {
        val mode = prefs.getString("loc_mode", "auto") ?: "auto"
        val city = prefs.getString("city", "") ?: ""
        val lat = prefs.getString("lat", null)?.toDoubleOrNull()
        val lon = prefs.getString("lon", null)?.toDoubleOrNull()
        var info = "الموقع الحالي: " + (if (city.isBlank()) "غير محدد" else city)
        if (lat != null && lon != null) info += "\n" + String.format(Locale.US, "%.3f , %.3f", lat, lon)
        tvLocInfo.text = info
        for ((k, v) in modeBtns) setSel(v, k == mode)
    }

    private fun status(msg: String) {
        tvStatus.text = msg
    }

    private fun saveLocation(mode: String, lat: Double, lon: Double, city: String) {
        prefs.edit()
            .putString("loc_mode", mode)
            .putString("lat", lat.toString())
            .putString("lon", lon.toString())
            .putString("city", city)
            .remove("p_date")
            .apply()
        status("تم حفظ الموقع: $city")
        resultsBox.removeAllViews()
        refreshLocInfo()
        loadMap(lat, lon)
    }

    private fun setAuto() {
        status("جارٍ تحديد الموقع من الإنترنت…")
        thread {
            val l = ipLocation()
            runOnUiThread {
                if (l != null) {
                    saveLocation("auto", l.first, l.second, l.third)
                } else {
                    prefs.edit().putString("loc_mode", "auto").apply()
                    status("تعذّر التحديد، تحقق من الإنترنت")
                    refreshLocInfo()
                }
            }
        }
    }

    private fun useGps() {
        if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            status("سيطلب التلفزيون إذن الموقع، اختر «السماح»")
            requestPermissions(
                arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION), 11
            )
            return
        }
        val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val providers = lm.getProviders(true).filter { it != LocationManager.PASSIVE_PROVIDER }
        if (providers.isEmpty()) {
            status("هذا التلفزيون لا يملك GPS أو خدمة الموقع مغلقة. استخدم «تلقائي» أو «يدوي».")
            return
        }
        status("جارٍ تحديد الموقع بالـ GPS…")
        try {
            lm.getCurrentLocation(providers[0], null, mainExecutor) { loc: Location? -> onGps(loc) }
        } catch (e: SecurityException) {
            status("لا يوجد إذن للموقع")
        }
    }

    private fun onGps(loc: Location?) {
        if (loc == null) {
            status("تعذّر الحصول على الموقع، جرّب «يدوي»")
            return
        }
        val lat = loc.latitude
        val lon = loc.longitude
        thread {
            val name = reverseName(lat, lon) ?: "موقع GPS"
            runOnUiThread { saveLocation("gps", lat, lon, name) }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 11) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                useGps()
            } else {
                status("لم يُمنح إذن الموقع")
            }
        }
    }

    private fun search() {
        val q = cityEdit.text.toString().trim()
        if (q.isEmpty()) {
            status("اكتب اسم المدينة أولاً")
            return
        }
        status("جارٍ البحث…")
        thread {
            val body = httpGet(
                "https://geocoding-api.open-meteo.com/v1/search?name=" + URLEncoder.encode(q, "UTF-8") +
                    "&count=8&language=ar&format=json"
            )
            val items = ArrayList<Place>()
            try {
                val arr = JSONObject(body ?: "{}").optJSONArray("results")
                if (arr != null) {
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        items.add(
                            Place(
                                o.optString("name"), o.optString("admin1"), o.optString("country"),
                                o.getDouble("latitude"), o.getDouble("longitude")
                            )
                        )
                    }
                }
            } catch (e: Exception) {
            }
            runOnUiThread { showResults(items, body != null) }
        }
    }

    private fun showResults(items: List<Place>, online: Boolean) {
        resultsBox.removeAllViews()
        if (items.isEmpty()) {
            status(if (online) "لا توجد نتائج، جرّب اسماً آخر" else "تعذّر الاتصال بالإنترنت")
            return
        }
        status("اختر مدينتك:")
        for (p in items) {
            val label = listOf(p.name, p.admin, p.country).filter { it.isNotEmpty() }.joinToString("، ")
            resultsBox.add(btn(label, 16f) { saveLocation("manual", p.lat, p.lon, p.name) }, 6)
        }
        resultsBox.getChildAt(0)?.requestFocus()
    }

    private fun showSavedMap() {
        val f = File(filesDir, "map.png")
        if (f.exists()) {
            val b = BitmapFactory.decodeFile(f.absolutePath)
            if (b != null) mapView.setImageBitmap(b)
        }
        val lat = prefs.getString("lat", null)?.toDoubleOrNull()
        val lon = prefs.getString("lon", null)?.toDoubleOrNull()
        if (lat != null && lon != null) {
            if (prefs.getString("map_key", "") != mapKey(lat, lon) || !f.exists()) loadMap(lat, lon)
        }
    }

    private fun mapKey(lat: Double, lon: Double) = String.format(Locale.US, "%.2f,%.2f", lat, lon)

    // خريطة من OpenStreetMap: 9 بلاطات حول الموقع + دبوس أحمر
    private fun loadMap(lat: Double, lon: Double) {
        val z = 10
        val n = 1 shl z
        val xf = (lon + 180.0) / 360.0 * n
        val latRad = Math.toRadians(lat)
        val yf = (1.0 - ln(tan(latRad) + 1.0 / cos(latRad)) / PI) / 2.0 * n
        val xt = floor(xf).toInt()
        val yt = floor(yf).toInt()
        thread {
            val bmp = Bitmap.createBitmap(768, 768, Bitmap.Config.ARGB_8888)
            val cv = Canvas(bmp)
            cv.drawColor(0xFF1C2740.toInt())
            var ok = false
            for (dy in -1..1) {
                for (dx in -1..1) {
                    val tx = ((xt + dx) % n + n) % n
                    val ty = yt + dy
                    if (ty < 0 || ty >= n) continue
                    val bytes = httpBytes("https://tile.openstreetmap.org/$z/$tx/$ty.png") ?: continue
                    val t = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: continue
                    cv.drawBitmap(t, ((dx + 1) * 256).toFloat(), ((dy + 1) * 256).toFloat(), null)
                    ok = true
                }
            }
            if (!ok) {
                runOnUiThread { status("تعذّر تحميل الخريطة (تحقق من الإنترنت)") }
                return@thread
            }
            val px = (256 + (xf - xt) * 256).toFloat()
            val py = (256 + (yf - yt) * 256).toFloat()
            val white = Paint(Paint.ANTI_ALIAS_FLAG)
            white.color = Color.WHITE
            val red = Paint(Paint.ANTI_ALIAS_FLAG)
            red.color = 0xFFD21034.toInt()
            cv.drawCircle(px, py, 22f, white)
            cv.drawCircle(px, py, 15f, red)
            try {
                FileOutputStream(File(filesDir, "map.png")).use { bmp.compress(Bitmap.CompressFormat.PNG, 90, it) }
                prefs.edit().putString("map_key", mapKey(lat, lon)).apply()
            } catch (e: Exception) {
            }
            runOnUiThread { mapView.setImageBitmap(bmp) }
        }
    }

    // ================= الخلفية =================
    private fun pageBackground(): View {
        val col = column()
        col.add(title("الخلفية المتحركة"), 0)
        btnOn = btn("") {
            prefs.edit().putBoolean("bg_on", !prefs.getBoolean("bg_on", true)).apply()
            refreshBgUi()
        }
        col.add(btnOn, 14)
        col.add(choice("ألوان التدرج (عند تعطيل الصور)", K.gradients,
            { prefs.getInt("grad_idx", 0) },
            { i -> prefs.edit().putInt("grad_idx", i).apply() }), 14)
        col.add(tv("مدة ظهور كل صورة (بالثواني):", 15f, K.MUTED), 12)
        val views = ArrayList<View>()
        for (s in listOf(10, 15, 30, 60)) {
            val b = btn("$s") {
                prefs.edit().putInt("bg_interval", s).apply()
                refreshBgUi()
            }
            intervalBtns[s] = b
            views.add(b)
        }
        col.add(rowOf(*views.toTypedArray()))
        tvDim = tv("", 15f, K.MUTED)
        col.add(tvDim, 12)
        col.add(rowOf(btn("−  أخف") { changeDim(-10) }, btn("+  أغمق") { changeDim(10) }))
        col.add(btn("إضافة صور من الملفات") { pickImages() }, 16)
        bgStatus = tv("", 15f, K.GOLD)
        col.add(bgStatus)
        col.add(hint("نصيحة: أرسل صورك للتلفزيون عبر Send Files to TV ثم اخترها من مجلد Download. الصور الأفقية تظهر أفضل."))
        col.add(tv("صورك (اضغط OK على صورة لحذفها):", 15f, Color.WHITE, true), 16)
        grid = GridLayout(this)
        grid.columnCount = 3
        col.add(grid)
        refreshBgUi()
        return wrap(col)
    }

    private fun changeDim(delta: Int) {
        val v = (prefs.getInt("bg_dim", 35) + delta).coerceIn(0, 90)
        prefs.edit().putInt("bg_dim", v).apply()
        refreshBgUi()
    }

    private fun refreshBgUi() {
        val on = prefs.getBoolean("bg_on", true)
        btnOn.text = if (on) "الخلفية المتحركة: مفعّلة (اضغط للتعطيل)" else "الخلفية المتحركة: معطّلة (اضغط للتفعيل)"
        val itv = prefs.getInt("bg_interval", 15)
        for ((s, b) in intervalBtns) setSel(b, s == itv)
        tvDim.text = "درجة التعتيم: " + prefs.getInt("bg_dim", 35) + "%"
        val files = bgFiles(this)
        thread {
            val items = files.map { f ->
                val o = BitmapFactory.Options()
                o.inSampleSize = 8
                o.inPreferredConfig = Bitmap.Config.RGB_565
                val b: Bitmap? = try {
                    BitmapFactory.decodeFile(f.absolutePath, o)
                } catch (e: Throwable) {
                    null
                }
                Pair(f, b)
            }
            runOnUiThread {
                grid.removeAllViews()
                for ((f, bmp) in items) {
                    val lp = GridLayout.LayoutParams()
                    lp.width = dp(130)
                    lp.height = dp(84)
                    lp.setMargins(dp(4), dp(4), dp(4), dp(4))
                    grid.addView(thumb(f, bmp), lp)
                }
                if (items.isEmpty()) bgStatus.text = "لا توجد صور بعد، تظهر خلفية ألوان متحركة افتراضية"
            }
        }
    }

    private fun thumb(f: File, bmp: Bitmap?): View {
        val acc = K.accent(prefs)
        val wrap = FrameLayout(this)
        wrap.isFocusable = true
        wrap.isClickable = true
        wrap.setPadding(dp(3), dp(3), dp(3), dp(3))
        wrap.background = rounded(K.ITEM, 8)
        wrap.setOnFocusChangeListener { v, focus -> v.background = rounded(if (focus) acc else K.ITEM, 8) }
        wrap.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("حذف هذه الصورة؟")
                .setPositiveButton("حذف") { _, _ ->
                    f.delete()
                    refreshBgUi()
                }
                .setNegativeButton("إلغاء", null)
                .show()
        }
        val iv = ImageView(this)
        iv.scaleType = ImageView.ScaleType.CENTER_CROP
        if (bmp != null) iv.setImageBitmap(bmp)
        wrap.addView(iv, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        return wrap
    }

    private fun pickImages() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "image/*"
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        try {
            startActivityForResult(i, 21)
        } catch (e: Exception) {
            try {
                val g = Intent(Intent.ACTION_GET_CONTENT)
                g.type = "image/*"
                g.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                startActivityForResult(g, 21)
            } catch (e2: Exception) {
                bgStatus.text = "لا يوجد تطبيق ملفات لاختيار الصور (جرّب تثبيت مدير ملفات)"
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 21 || resultCode != RESULT_OK || data == null) return
        val uris = ArrayList<Uri>()
        val clip = data.clipData
        if (clip != null) {
            for (i in 0 until clip.itemCount) uris.add(clip.getItemAt(i).uri)
        } else {
            val u = data.data
            if (u != null) uris.add(u)
        }
        bgStatus.text = "جارٍ إضافة الصور…"
        thread {
            var count = 0
            for (u in uris) if (importImage(u)) count++
            runOnUiThread {
                bgStatus.text = "تمت إضافة $count صورة"
                refreshBgUi()
            }
        }
    }

    // نسخ الصورة إلى مخزن التطبيق بحجم مناسب (حتى 1920x1080)
    private fun importImage(uri: Uri): Boolean {
        return try {
            val bounds = BitmapFactory.Options()
            bounds.inJustDecodeBounds = true
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / sample > 2400 || bounds.outHeight / sample > 1400) sample *= 2
            val o = BitmapFactory.Options()
            o.inSampleSize = sample
            val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
                ?: return false
            val scale = minOf(1920f / bmp.width, 1080f / bmp.height, 1f)
            val out = if (scale < 1f) {
                Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt(), (bmp.height * scale).toInt(), true)
            } else {
                bmp
            }
            val name = "bg_" + System.currentTimeMillis() + "_" + (Math.random() * 1000).toInt() + ".jpg"
            FileOutputStream(File(bgDir(this), name)).use { out.compress(Bitmap.CompressFormat.JPEG, 88, it) }
            true
        } catch (e: Throwable) {
            false
        }
    }

    // ================= التطبيقات (إدارة أسهل) =================
    private fun pageApps(): View {
        val col = column()
        col.add(title("التطبيقات"), 0)
        col.add(choice("عدد الأعمدة في الشاشة الرئيسية", K.colsOptions.map { it.toString() },
            { prefs.getInt("cols_idx", 1) },
            { i -> prefs.edit().putInt("cols_idx", i).apply() }), 14)
        col.add(choice("حجم الأيقونات", listOf("صغير", "متوسط", "كبير"),
            { prefs.getInt("icon_size", 1) },
            { i -> prefs.edit().putInt("icon_size", i).apply() }), 14)
        col.add(choice("أسماء التطبيقات", listOf("عند التحديد فقط", "دائماً ظاهرة"),
            { if (prefs.getBoolean("labels_always", false)) 1 else 0 },
            { i -> prefs.edit().putBoolean("labels_always", i == 1).apply() }), 14)
        col.add(tv("إدارة التطبيقات", 20f, K.GOLD, true), 20)
        col.add(hint("«تثبيت» ينقل التطبيق إلى صف المفضلة في الأعلى. استخدم «أعلى» و«أسفل» للترتيب."), 6)
        col.add(rowOf(
            btn("إظهار كل المخفية", 14f, 12) {
                store.showAll()
                rebuildAppList(null, 0)
            },
            btn("الترتيب الافتراضي", 14f, 12) {
                store.resetOrder()
                rebuildAppList(null, 0)
            }
        ), 10)
        appListBox = LinearLayout(this)
        appListBox.orientation = LinearLayout.VERTICAL
        col.add(appListBox, 6)
        thread {
            val all = store.loadAll()
            runOnUiThread {
                manageAll = all
                rebuildAppList(null, 0)
            }
        }
        return wrap(col)
    }

    private fun rebuildAppList(focusPkg: String?, btnIdx: Int) {
        appListBox.removeAllViews()
        val s = store.sections(manageAll)
        var focusView: View? = null
        fun addSection(title: String, apps: List<AppItem>, hiddenSec: Boolean) {
            if (apps.isEmpty()) return
            appListBox.add(tv(title, 17f, K.GOLD, true), 14)
            for (a in apps) {
                val r = appRow(a, hiddenSec)
                appListBox.add(r.first, 6)
                if (a.pkg == focusPkg) focusView = r.second.getOrNull(btnIdx) ?: r.second.firstOrNull()
            }
        }
        addSection("المفضلة", s.pinned, false)
        addSection("التطبيقات الظاهرة", s.rest, false)
        addSection("المخفية", s.hidden, true)
        focusView?.requestFocus()
    }

    private fun appRow(a: AppItem, hiddenSec: Boolean): Pair<View, List<TextView>> {
        val row = LinearLayout(this)
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(12), dp(6), dp(8), dp(6))
        row.background = rounded(0x66141C2E, 14)
        val ic = ImageView(this)
        ic.setImageDrawable(a.icon)
        row.addView(ic, LinearLayout.LayoutParams(dp(40), dp(40)))
        val name = tv(a.label, 17f, Color.WHITE, true)
        name.setPadding(dp(12), 0, dp(12), 0)
        row.addView(name, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        val buttons = ArrayList<TextView>()
        fun addBtn(label: String, action: () -> Unit) {
            val idx = buttons.size
            val b = btn(label, 14f, 12) {
                action()
                rebuildAppList(a.pkg, idx)
            }
            buttons.add(b)
            row.addView(b, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply {
                setMargins(dp(3), 0, dp(3), 0)
            })
        }
        if (hiddenSec) {
            addBtn("إظهار") { store.show(a.pkg) }
        } else {
            addBtn(if (store.isPinned(a.pkg)) "إلغاء التثبيت" else "تثبيت") { store.togglePin(a.pkg) }
            addBtn("أعلى") { store.move(manageAll, a.pkg, -1, false) }
            addBtn("أسفل") { store.move(manageAll, a.pkg, 1, false) }
            addBtn("إخفاء") { store.hide(a.pkg) }
        }
        return Pair(row, buttons)
    }
}
